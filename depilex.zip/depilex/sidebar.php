            <!--Right Sidebar-->
			<?php if ( is_active_sidebar( 'depilex_sidebar' ) ) { ?>
            <div class="col-md-4 col-sm-12 col-xs-12">
        	<!-- sidebar -->
            <div class="side-bar">
                    <!--widget area-->
                    <?php dynamic_sidebar( 'depilex_sidebar' ); ?>
                    <!--End widget area-->
            </div>
			</div>
			<?php } ?>
            <!--End Right Sidebar-->
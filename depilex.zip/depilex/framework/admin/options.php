<?php

/* -----------------------------------------------------------------------------
 * Helper Function
 * -------------------------------------------------------------------------- */
function depilex_get_option( $opt_name, $default = null ) {
	global $Redux_Options;
	return $Redux_Options->get( $opt_name, $default );
}
/* -----------------------------------------------------------------------------
 * Load Custom Fields
 * -------------------------------------------------------------------------- */
require_once( DEPILEX_ADMIN_PATH . 'custom-fields/field_font_upload/field_upload.php' );
require_once( DEPILEX_ADMIN_PATH . 'custom-fields/field_typography.php' );
require_once( DEPILEX_ADMIN_PATH . 'custom-fields/field_section_info.php' );
require_once( DEPILEX_ADMIN_PATH . 'custom-fields/field_sidebar_select.php' );
require_once( DEPILEX_ADMIN_PATH . 'custom-fields/field_color_scheme.php' );
require_once( DEPILEX_ADMIN_PATH . 'custom-fields/field_slider.php' );
require_once( DEPILEX_ADMIN_PATH . 'custom-fields/field_slides.php' );
/* -----------------------------------------------------------------------------
 * Initial Redux Framework
 * -------------------------------------------------------------------------- */


if(!class_exists('Redux_Options')) {
	require_once( DEPILEX_ADMIN_PATH . 'options/defaults.php' );
}
/*
 *
 * Most of your editing will be done in this section.
 *
 * Here you can override default values, uncomment args and change their values.
 * No $args are required, but they can be over ridden if needed.
 *
 */
function depilex_setup_framework_options() {
	$args = array();

	$args['std_show'] = true; // If true, it shows the std value

	// Set the class for the dev mode tab icon.
	// This is ilicered unless $args['icon_type'] = 'iconfont'
	// Default: null
	$args['dev_mode_icon_class'] = 'icon-large';

	// Setup custom links in the footer for share icons
	$args['share_icons']['twitter'] = array(
		'link' => 'http://twitter.com/ghost1227',
		'title' => esc_html__('Follow me on Twitter', 'depilex'),
		'img' => Redux_OPTIONS_URL . 'img/social/Twitter.png'
	);
	$args['share_icons']['linked_in'] = array(
		'link' => 'http://www.linkedin.com/profile/view?id=52559281',
		'title' => esc_html__('Find me on LinkedIn', 'depilex'),
		'img' => Redux_OPTIONS_URL . 'img/social/LinkedIn.png'
	);

	// Set the class for the import/export tab icon.
	// This is ilicered unless $args['icon_type'] = 'iconfont'
	// Default: null
	$args['import_icon_class'] = 'icon-large';

	// Set a custom option name. Don't forget to replace spaces with underscores!
	$args['opt_name'] = 'depilex_theme_options';

	// Set a custom title for the options page.
	// Default: Options
	$args['menu_title'] = esc_html__('Theme Options', 'depilex');

	// Set a custom page title for the options page.
	// Default: Options
	$args['page_title'] = esc_html__('Theme Options', 'depilex');

	// Set a custom page slug for options page (wp-admin/themes.php?page=***).
	// Default: redux_options
	$args['page_slug'] = 'redux_options';

	// Set the menu type. Set to "menu" for a top level menu, or "submenu" to add below an existing item.
	// Default: menu
	$args['page_type'] = 'menu';

	// Set the parent menu.
	// Default: themes.php
	$args['page_parent'] = 'themes.php';

	// Set the icon type. Set to "iconfont" for Font Awesome, or "image" for traditional.
	// Redux no longer ships with standard icons!
	// Default: iconfont
	$args['dev_mode_icon_type'] = 'iconfont';
	$args['import_icon_type'] = 'iconfont';
	$allowed_html_array = array(
    'p' => array(),
    'h4' => array(),
	'strong' => array(),
	);
	$args['intro_text'] = wp_kses( __( '<h4>Theme Settings Information for depilex Theme</h4>', 'depilex' ), $allowed_html_array );

	$sections = array();
	
	//section for General-logo, favicon, ratina, custom css
	$sections[] = array(
						'icon_type' => 'iconfont',
						'icon' => 'globe',
						'icon_class' => 'icon-large',
						'title' => esc_html__('General', 'depilex'),
						'desc' => wp_kses( __('<p class="description">This is the general options.</p>', 'depilex'), $allowed_html_array ),
						'fields' => array(
										    array(
												'id' => 'logo_url',
												'type' => 'upload',
												'title' => esc_html__('Upload Main Logo', 'depilex'),
												'sub_desc' => esc_html__('This is the main logo', 'depilex'),
											),
											
											array(
												'id' => 'depilex_favicon',
												'type' => 'upload',
												'title' => esc_html__('Upload Favicon', 'depilex'),
												'sub_desc' => esc_html__('This is favicon. Upload 64x64 favicon icon.', 'depilex'),
											),	

											array(
												'id' => 'logo_url_innerpage',
												'type' => 'upload',
												'title' => esc_html__('Upload Inner-Page Logo', 'depilex'),
												'sub_desc' => esc_html__('You can leave it empty if you do not use Header Style - 4. Inner-Page Logo works with Header Style - 4 Only', 'depilex'),
											),
											
											array(
												'id' => 'custom_color',
												'type' => 'color',
												'title' => esc_html__('Website Global Color', 'depilex'), 
												'sub_desc' => esc_html__('Choose Global Color from here', 'depilex'),
												'desc' => esc_html__('Keep it empty if you like to use the default color (#F9A392)', 'depilex'),
												'std' => ''
											),
											
											array(
                                                                'id' => 'depilex_page_header_title',
                                                                'type' => 'text',
                                                                'title' => esc_html__('Index Page / Blog Page Header Title', 'depilex'),
                                                                'sub_desc' => '',
                                                                'std' => '',
                                                    ),
											
											array( 
												"title" => esc_html__("Custom CSS", 'depilex'),
												"sub_desc" => esc_html__("Advanced CSS options. Paste your CSS code and it will override existing code style.", 'depilex'),
												"id" => "textarea_csscode",
												"std" => "",
												"type" => "textarea"
											),

										)
	);
	
		//section for Social icon url
	$sections[] = array(
					'icon_type' => 'iconfont',
					'icon' => 'star',
					'icon_class' => 'icon-large',
					'title' => esc_html__('Header', 'depilex'),
					'desc' => wp_kses( __('<p class="description">This is options for setting up the content of the header of your website.', 'depilex'), $allowed_html_array ),
					'fields' => array(
                                                    array(
														'id' => 'header_top_bar',
														'type' => 'checkbox',
														'title' => esc_html__('On/Off Top Bar', 'depilex'),
														'switch' => true,
														'std' => '1' // 1 = checked | 0 = unchecked
													),
											
													array(
                                                                'id' => 'depilex_opening_hours',
                                                                'type' => 'text',
                                                                'title' => esc_html__('Top-Left Corner Text', 'depilex'),
                                                                'sub_desc' => esc_html__('Top-Left corner openning hours text', 'depilex'),
                                                                'std' => '',
                                                    ),

													array(
																'id' => 'depilex_appointment_label',
																'type' => 'text',
																'title' => esc_html__('Appointment Button Label', 'depilex'), 
																'sub_desc' => esc_html__('The appointment button label exists at the right corner of menu bar', 'depilex'),
																'std' => '',
													),													
													
													array(
																'id' => 'depilex_appointment_url',
																'type' => 'text',
																'title' => esc_html__('Appointment Button URL', 'depilex'), 
																'sub_desc' => esc_html__('The appointment button url', 'depilex'),
																'std' => '',
													),
													
													array(
																'id' => 'depilex_email_title',
																'type' => 'text',
																'title' => esc_html__('Email Title of Header', 'depilex'), 
																'sub_desc' => esc_html__('Default email title is - Email', 'depilex'),
																'desc' => esc_html__('Email title will be visible only if you go to Footer/Contact settings and input your email id in the required field.', 'depilex'),
																'std' => '',
													),
													
													array(
																'id' => 'depilex_phn_title',
																'type' => 'text',
																'title' => esc_html__('Phone Title of Header', 'depilex'), 
																'sub_desc' => esc_html__('Default phone title is - Call Now', 'depilex'),
																'desc' => esc_html__('Phone title will be visible only if you go to Footer/Contact settings and input your pnone number in the required field.', 'depilex'),
																'std' => '',
													),
													
													array(
																'id' => 'depilex_header_address_title',
																'type' => 'text',
																'title' => esc_html__('Address Title of Header', 'depilex'), 
																'sub_desc' => esc_html__('Default address title is - Find Us', 'depilex'),
																'std' => '',
													),
													
													array(
																'id' => 'depilex_header_address_info',
																'type' => 'text',
																'title' => esc_html__('Short Address of Header', 'depilex'), 
																'sub_desc' => esc_html__('Write a short address within 20 charecters.', 'depilex'),
																'std' => '',
													),
													
													array(
																'id' => 'depilex_header_address_url',
																'type' => 'text',
																'title' => esc_html__('Address Hyperlink', 'depilex'), 
																'sub_desc' => esc_html__('The address url where user can click to view the full address/contact page', 'depilex'),
																'std' => '',
													),
							)
				);
				
		//section for Social icon url
	$sections[] = array(
					'icon_type' => 'iconfont',
					'icon' => 'group',
					'icon_class' => 'icon-large',
					'title' => esc_html__('Social Media', 'depilex'),
					'desc' => wp_kses( __('<p class="description">This is options for setting up the social media of website. Do not forget to use http:// for any social urls.</p>', 'depilex'), $allowed_html_array ),
					'fields' => array(
                                                    array(
																'id' => 'social_facebook',
																'type' => 'text',
																'title' => esc_html__('Facebook URL', 'depilex'), 
																'sub_desc' => esc_html__('The URL to your account page', 'depilex'),
																'std' => '',
													),
													
													array(
                                                                'id' => 'social_twitter',
                                                                'type' => 'text',
                                                                'title' => esc_html__('Twitter URL', 'depilex'),
                                                                'sub_desc' => esc_html__('The URL to your account page', 'depilex'),
                                                                'std' => '',
                                                    ),
													
													array(
                                                                'id' => 'social_linkedin',
                                                                'type' => 'text',
                                                                'title' => esc_html__('Linkedin URL', 'depilex'),
                                                                'sub_desc' => esc_html__('The URL to your account page', 'depilex'),
                                                                'std' => '',
                                                    ),

													array(
																'id' => 'social_googleplus',
																'type' => 'text',
																'title' => esc_html__('GooglePlus URL', 'depilex'), 
																'sub_desc' => esc_html__('The URL to your account page', 'depilex'),
																'std' => '',
													),													
													
													array(
																'id' => 'social_flickr',
																'type' => 'text',
																'title' => esc_html__('Flicker URL', 'depilex'), 
																'sub_desc' => esc_html__('The URL to your account page', 'depilex'),
																'std' => '',
													),
													
													array(
																'id' => 'social_utube',
																'type' => 'text',
																'title' => esc_html__('YouTube URL', 'depilex'), 
																'sub_desc' => esc_html__('The URL to your account page', 'depilex'),
																'std' => '',
													),
													
													array(
																'id' => 'social_instagram',
																'type' => 'text',
																'title' => esc_html__('Instagram URL', 'depilex'), 
																'sub_desc' => esc_html__('The URL to your account page', 'depilex'),
																'std' => '',
													),
							)
				);

						
		//section for Footer
					$sections[] = array(
							'icon_type' => 'iconfont',
							'icon' => 'columns',
							'icon_class' => 'icon-large',
							'title' => esc_html__('Footer/Contact', 'depilex'),
							'desc' => wp_kses( __('<p class="description">This is options for Footer and Contact.</p>', 'depilex'), $allowed_html_array ),
							'fields' => array(
											
											
											array(
												'id' => 'depilex_fabout_title',
												'type' => 'text',
												'title' => esc_html__('Footer About Column Heading', 'depilex'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'depilex_about_info',
												'type' => 'textarea',
												'title' => esc_html__('About Company Text', 'depilex'),
												'sub_desc' => esc_html__('Enter your company info here', 'depilex'),
												'std' => '',
											),																																																						
											
											array(
												'id' => 'depilex_fblog_title',
												'type' => 'text',
												'title' => esc_html__('Footer Blog / Flickr Column Heading', 'depilex'), 
												'sub_desc' => '',
												'std' => '',
											),		

											array(
												'id' => 'depilex_footer_flickr',
												'type' => 'checkbox',
												'title' => esc_html__('Use Flickr Photos Instead of Blog Posts', 'depilex'),
												'sub_desc' => esc_html__('In second column of the footer, use flickr photos instead of blog posts.', 'depilex'),
												'switch' => true,
												'std' => '0' // 1 = checked | 0 = unchecked
											),
											
											array(
												'id' => 'depilex_flickr_id',
												'type' => 'text',
												'title' => esc_html__('You Flickr ID', 'depilex'), 
												'sub_desc' => 'Example Flickr ID: 120958634@N07',
												'std' => '',
											),
											
											array(
												'id' => 'depilex_fcontact_title',
												'type' => 'text',
												'title' => esc_html__('Footer Contact Column Heading', 'depilex'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'depilex_address_info',
												'type' => 'textarea',
												'title' => esc_html__('Your Company Address', 'depilex'), 
												'sub_desc' => esc_html__('Enter your company address here', 'depilex'),
												'std' => '',
											),
											
											array(
												'id' => 'depilex_phn_number',
												'type' => 'text',
												'title' => esc_html__('Your Contact Phone Number', 'depilex'), 
												'sub_desc' => esc_html__('Enter your company info here. This will be visible in Footer and Contact page.', 'depilex'),
												'std' => '',
											),
											
											array(
												'id' => 'depilex_email_id',
												'type' => 'text',
												'title' => esc_html__('Your Contact Email ID', 'depilex'), 
												'sub_desc' => esc_html__('Enter your company info here. This will be visible in Footer and Contact page.', 'depilex'),
												'std' => '',
											),	
											
											array(
												'id' => 'depilex_cnletter_title',
												'type' => 'text',
												'title' => esc_html__('Newsletter Column Heading', 'depilex'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'depilex_cnletter_text',
												'type' => 'text',
												'title' => esc_html__('Newsletter Column Text', 'depilex'), 
												'sub_desc' => '',
												'std' => '',
											),
											
											array(
												'id' => 'depilex_cnletter_nodisplay',
												'type' => 'checkbox',
												'title' => esc_html__('Remove Newsletter from Footer', 'depilex'), 
												'sub_desc' => '',
												'switch' => true,
												'std' => '0' // 1 = checked | 0 = unchecked
											),
											
											
											array(
												'id' => 'copy_text',
												'type' => 'textarea',
												'title' => esc_html__('Copyright Text', 'depilex'),
												'sub_desc' => esc_html__('Enter your Copyright text here', 'depilex'),
												'std' => '',
											),
											
							)
						);
						
		//section for aweber
					$sections[] = array(
							'icon_type' => 'iconfont',
							'icon' => 'cog',
							'icon_class' => 'icon-large',
							'title' => esc_html__('MailChimp/Aweber Newsletter', 'depilex'),
							'desc' => wp_kses( __('<p class="description">MailChimp and Aweber settings for footer subscriber form of Depilex</p>', 'depilex'), $allowed_html_array ),
							'fields' => array(

													array(
																'id' => 'mailchimp_apikey',
																'type' => 'text',
																'title' => esc_html__('MailChimp API Key', 'depilex'), 
																'sub_desc' => esc_html__('The unique API Key of your MailChimp account', 'depilex'),
																'std' => '',
													),
													array(
																'id' => 'mailchimp_listid',
																'type' => 'text',
																'title' => esc_html__('MailChimp List ID', 'depilex'), 
																'sub_desc' => esc_html__('The unique List ID of your MailChimp account', 'depilex'),
																'std' => '',															
													),
													array(
																'id' => '123',
																'type' => 'info',
																'desc' => esc_html__('If you want to use Aweber instead of MailChimp use the settings below and keep the above MailChimp fields empty.', 'depilex'),
													),
													array(
																'id' => 'ft_aweber_listid',
																'type' => 'text',
																'title' => esc_html__('Aweber List ID', 'depilex'), 
																'sub_desc' => esc_html__('The unique List ID of Aweber account', 'depilex'),
																'std' => '',
													),
													array(
																'id' => 'aweber_redirectpage',
																'type' => 'text',
																'title' => esc_html__('Redirect Page URL', 'depilex'), 
																'sub_desc' => esc_html__('Redirect page url after submission of Aweber form', 'depilex'),
																'std' => '',
													),
													array(
																'id' => 'aweber_redirectpage_old',
																'type' => 'text',
																'title' => esc_html__('Redirect Page URL for already subscribed users', 'depilex'), 
																'sub_desc' => esc_html__('Redirect page url for already subscribed users of Aweber', 'depilex'),
																'std' => '',
													),
							)
						);

		//section for page
					$sections[] = array(
							'icon_type' => 'iconfont',
							'icon' => 'cogs',
							'icon_class' => 'icon-large',
							'title' => esc_html__('Other Settings', 'depilex'),
							'desc' => wp_kses( __('<p class="description">Other Settings</p>', 'depilex'), $allowed_html_array ),
							'fields' => array(
																						
											array(
												'id' => 'depilex_preloader',
												'type' => 'checkbox',
												'title' => esc_html__('On/Off Page Loader GIF', 'depilex'),
												'sub_desc' => esc_html__('On/Off Page Loader GIF', 'depilex'),
												'switch' => true,
												'std' => '1' // 1 = checked | 0 = unchecked
											),
											
											array(
												'id' => 'depilex_smooth_scroll',
												'type' => 'checkbox',
												'title' => esc_html__('On/Off Smooth Scroll', 'depilex'),
												'sub_desc' => esc_html__('On/Off Smooth Scroll', 'depilex'),
												'switch' => true,
												'std' => '0' // 1 = checked | 0 = unchecked
											),
											
											array(
												'id' => 'depilex_page_header_img',
												'type' => 'upload',
												'title' => esc_html__('Page Header Background Image', 'depilex'),
												'sub_desc' => esc_html__('Upload Header Background Image for General Pages and Posts', 'depilex'),
											),		

											array(
												'id' => 'depilex_blog_post_meta',
												'type' => 'checkbox',
												'title' => esc_html__('On/Off Post Meta for Blog', 'depilex'),
												'sub_desc' => esc_html__('On/Off Post Meta for Blog Pages', 'depilex'),
												'switch' => true,
												'std' => '1' // 1 = checked | 0 = unchecked
											),
											
											array(
												'id' => 'depilex_single_post_meta',
												'type' => 'checkbox',
												'title' => esc_html__('On/Off Post Meta for Single Post', 'depilex'),
												'sub_desc' => esc_html__('On/Off Post Meta for Single Post Page', 'depilex'),
												'switch' => true,
												'std' => '1' // 1 = checked | 0 = unchecked
											),
											
											array(
                                                                'id' => 'depilex_readmore_label',
                                                                'type' => 'text',
                                                                'title' => esc_html__('Label of Read More Buttons', 'depilex'),
                                                                'sub_desc' => 'Input a label if you want something else rather than Read More. Default is Read More',
                                                                'std' => '',
                                                    ),
											array(
												'id' => 'depilex_woocommerce_sidebar_switch',
												'type' => 'checkbox',
												'title' => esc_html__('On/Off Shop Sidebar', 'depilex'),
												'sub_desc' => esc_html__('On/Off WooCommerce Shop Sidebar', 'depilex'),
												'switch' => true,
												'std' => '0' // 1 = checked | 0 = unchecked
											),
							)
						);						

                        

	$tabs = array();

		$theme_data = wp_get_theme();
		$item_uri = $theme_data->get('ThemeURI');
		$description = $theme_data->get('Description');
		$author = $theme_data->get('Author');
		$author_uri = $theme_data->get('AuthorURI');
		$version = $theme_data->get('Version');
		$tags = $theme_data->get('Tags');

	
	$item_info = '<div class="redux-opts-section-desc">';
	$item_info .= '<p class="redux-opts-item-data description item-uri">' . wp_kses( __('<strong>Theme URL:</strong> ', 'depilex'), $allowed_html_array ) . '<a href="' . esc_url( $item_uri ) . '" target="_blank">' . $item_uri . '</a></p>';
	$item_info .= '<p class="redux-opts-item-data description item-author">' . wp_kses( __('<strong>Author:</strong> ', 'depilex'), $allowed_html_array ) . ($author_uri ? '<a href="' . esc_url( $author_uri ) . '" target="_blank">' . $author . '</a>' : $author) . '</p>';
	$item_info .= '<p class="redux-opts-item-data description item-version">' . wp_kses( __('<strong>Version:</strong> ', 'depilex'), $allowed_html_array ) . $version . '</p>';
	$item_info .= '<p class="redux-opts-item-data description item-description">' . $description . '</p>';
	$item_info .= '<p class="redux-opts-item-data description item-tags">' . wp_kses( __('<strong>Tags:</strong> ', 'depilex'), $allowed_html_array ) . implode(', ', $tags) . '</p>';
	$item_info .= '</div>';

	global $Redux_Options;
	$Redux_Options = new Redux_Options($sections, $args, $tabs);
}
add_action('init', 'depilex_setup_framework_options', 0);
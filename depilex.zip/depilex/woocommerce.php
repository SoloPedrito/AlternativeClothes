<?php
/**
 * The default woocommerce template of this theme
 */
get_header();
global $product;
$id = $product->id;
?>
  <!-- =-=-=-=-=-=-= PAGE HEADING SECTION =-=-=-=-=-=-= -->
  <section class="page-heading breadcrumb-image">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="page-heading_content fleft">
			<?php if ( !is_product() ) { ?>
            <h1><span><?php woocommerce_page_title(); ?></span></h1>
			<?php } else { ?>
			<h1><span><?php echo get_the_title( $id ); ?></span></h1>
			<?php } ?>
          </div>
        </div>
		<div class="col-md-6">
          <div class="page-heading_content fright">
            <div class="bredcrumbs"><?php if (function_exists('woocommerce_breadcrumb')) woocommerce_breadcrumb(); ?></div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- =-=-=-=-=-=-= PAGE HEADING SECTION END =-=-=-=-=-=-= -->
  
 <section class="section-padding woocommerce-padding">
    <div class="container">
      <div class="row">
		<?php if ( is_shop() ) { ?>
        <div class="<?php if(depilex_get_option('depilex_woocommerce_sidebar_switch') == '1') { ?>col-md-8 col-sm-12<?php } else { ?>col-md-12<?php } ?>">
		<?php } else { ?>
		<div class="col-md-12">
		<?php } ?>
        <!-- post content -->
        <div class="post-content">

					<?php woocommerce_content(); ?>

        </div>
          <!-- post grid end -->
						
      </div>
	  
	  <?php if ( is_shop() ) { ?>
	  <?php if(depilex_get_option('depilex_woocommerce_sidebar_switch') == '1') { ?>
			<!--WooCommerce Sidebar-->
			<?php if ( is_active_sidebar( 'depilex_woocommerce_sidebar' ) ) { ?>
            <div class="col-md-4 col-sm-12 col-xs-12 woo-sidebar">
                    <!--widget area-->
                    <?php dynamic_sidebar( 'depilex_woocommerce_sidebar' ); ?>
                    <!--End widget area-->
            </div>
			<?php } ?>
            <!--End WooCommerce Sidebar-->
			<?php } ?>
	  <?php } ?>

    </div>
    </div>
  </section>
  <!-- end -->
  <?php get_footer(); ?>
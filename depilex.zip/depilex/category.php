<?php
/**
 * The template for displaying Category pages
 */
get_header(); ?>
<!-- =-=-=-=-=-=-= PAGE HEADING SECTION =-=-=-=-=-=-= -->
  <section class="page-heading breadcrumb-image" <?php if(depilex_get_option('depilex_page_header_img') != '') { ?>style="background: rgba(0, 0, 0, 0) url('<?php echo esc_url( depilex_get_option('depilex_page_header_img') ); ?>'); background-repeat: no-repeat; background-size: cover; background-position: center center; background-attachment: fixed;"<?php } ?>>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="page-heading_content text-center">
            <h1><span><?php single_cat_title('Articles from '); ?></span></h1>
            <div class="bredcrumbs"><?php if (function_exists('depilex_wordpress_breadcrumbs')) depilex_wordpress_breadcrumbs(); ?></div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- =-=-=-=-=-=-= PAGE HEADING SECTION END =-=-=-=-=-=-= -->

<section class="section-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-sm-12 col-xs-12"> 
			
				<?php if (have_posts()) :  while (have_posts()) : the_post(); 
					$depilex_global_post = depilex_get_global_post();
					$postid = $depilex_global_post->ID;
					$get_image = esc_url( wp_get_attachment_url( get_post_thumbnail_id($postid) ) ); 
				?>
		<!-- post grid -->
          <div <?php post_class( 'post-block' ); ?> id="post-<?php the_ID(); ?>">
        <!-- image grid -->
		<?php if ( has_post_thumbnail()) : ?>
        <div class="post-image zoom-pic">
            <a href="<?php the_permalink(); ?>"><img alt="" class="img-responsive" src="<?php echo esc_url( $get_image ); ?>"></a>
        </div>
		<?php endif; ?>
		<!-- image grid end -->
        <!-- post content -->
        <div class="post-content">
            <a href="<?php the_permalink(); ?>"><span class="meta-bg"><span class="date"><?php echo get_the_time('j'); ?></span><span><?php echo get_the_time('M'); ?></span></span></a>
            <h2><a class="post-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
             <!-- post meta -->
            <div class="meta">
                <span class="meta-comment">
                	<i class="fa fa-commenting"></i>
                 <a class="meta-link" href="<?php echo get_comments_link(); ?>"><?php esc_html_e('Comments', 'depilex'); ?> (<?php echo get_comments_number(); ?>)</a>
                </span>
                <span class="meta-author">
                	<i class="fa fa-user"></i>
                	<?php esc_html_e('By', 'depilex'); ?> <?php the_author_posts_link(); ?>
                </span>
				<?php if ( has_category() ) { ?>
                <span class="meta-tag">
                	<i class="fa fa-tags"></i>
                	<?php the_category(', '); ?>
                </span>
				<?php } if ( has_tag() ) { ?>
				<span class="meta-tag">
                	<i class="fa fa-tags"></i>
                	<?php the_tags(); ?>
                </span>
				<?php } ?>
            </div>
            <!-- post meta -->
            <?php if ( has_post_format( 'video' ) ) : ?>
					<?php the_content(); ?>
					<?php else: ?>
					<?php the_excerpt(); ?>
			<?php endif; ?>
            <a class="btn btn-blog btn-default " href="<?php the_permalink(); ?>"><i class="fa fa-plus"></i> <?php if(depilex_get_option('depilex_readmore_label') != '') { ?><?php echo esc_html( depilex_get_option('depilex_readmore_label') ); ?><?php } else { ?><?php esc_html_e('Read More', 'depilex'); ?><?php } ?></a>
        </div>
         <!-- post content end -->
		</div>
          <!-- post grid end -->
		<?php endwhile; endif; ?>
        <div class="clearfix"></div>
          
          <span class="separator"></span>         
              <div class="custom-pagination text-center">
                <?php depilex_custom_pagination(); ?>
              </div>
						
      </div>
	  
	  <!--Sidebar-->
			<?php get_sidebar(); ?>
	  <!--Sidebar end-->
    </div>
    </div>
  </section>
  <!-- end -->
  <?php get_footer(); ?>
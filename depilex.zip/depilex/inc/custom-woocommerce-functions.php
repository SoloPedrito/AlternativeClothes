<?php
// **********************************************************************// 
// ! Function is_woocommerce_activated
// **********************************************************************//
if ( ! function_exists( 'is_woocommerce_activated' ) ) {
	function is_woocommerce_activated() {
		if ( class_exists( 'woocommerce' ) ) { return true; } else { return false; }
	}
}

// **********************************************************************// 
// ! Declare WooCommerce support in third party theme
// **********************************************************************//
add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

// **********************************************************************// 
// ! Customizing number of products in shop page
// **********************************************************************//
	add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 12;' ), 20 );
	
// *************************************************************************// 
// ! Ensure cart contents update when products are added to the cart via AJAX
// *************************************************************************//
add_filter( 'woocommerce_add_to_cart_fragments', 'depilex_woocommerce_header_add_to_cart_fragment' );
function depilex_woocommerce_header_add_to_cart_fragment( $fragments ) {
	ob_start();
	?>
	<span class="depilex_cart_count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
	<?php
	
	$fragments['span.depilex_cart_count'] = ob_get_clean();
	
	return $fragments;
}

// **********************************************************************// 
// ! Enqueue Custom WooCommerce Styles
// **********************************************************************//
if ( class_exists( 'woocommerce' ) ) {
function depilex_add_footer_styles() {
    /* woocommerce */
	wp_enqueue_style( 'depilex-shop-templates.css', get_template_directory_uri() . '/css/shop-templates.css');
};
add_action( 'get_footer', 'depilex_add_footer_styles' );
}

// **********************************************************************// 
// ! Enqueue Custom WooCommerce JS
// **********************************************************************//
function depilex_woocommerce_scripts_basic() {  
wp_enqueue_script('depilex-woocommerce', get_template_directory_uri() . '/js/depilex-woocommerce.js', array( 'jquery' ), '1.0.0', true);
}
add_action( 'wp_enqueue_scripts', 'depilex_woocommerce_scripts_basic' ); 

// **********************************************************************// 
// ! Customizing open and close a href tags of product loop
// **********************************************************************//
remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );

// **********************************************************************// 
// ! Customizing title of loop product
// **********************************************************************//
remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );

// **********************************************************************// 
// ! Customizing star rating of product loop
// **********************************************************************//
add_filter('woocommerce_product_get_rating_html', 'depilex_rating_removal');
function depilex_rating_removal( $rating_variable ) {
$rating_variable = '<div class="star-rating nodisplay"></div>';
return $rating_variable;
}


// **********************************************************************// 
// ! Customizing image of product loop
// **********************************************************************//
remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);
add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);
/**
 * WooCommerce Loop Product Thumbs
 **/
 if ( ! function_exists( 'woocommerce_template_loop_product_thumbnail' ) ) {
	function woocommerce_template_loop_product_thumbnail() {
		echo woocommerce_get_product_thumbnail();
	} 
 }
/**
 * WooCommerce Product Thumbnail
 **/
 if ( ! function_exists( 'woocommerce_get_product_thumbnail' ) ) {
	 
	function woocommerce_get_product_thumbnail( $size = 'shop_catalog', $deprecated1 = 0, $deprecated2 = 0 ) {
		global $post;
		global $product;
		$image_size = apply_filters( 'single_product_archive_thumbnail_size', $size );

		if ( has_post_thumbnail() ) {
			$props = wc_get_product_attachment_props( get_post_thumbnail_id(), $post );
			$output = '<div class="col-md-4 col-sm-6 col-xs-12">
          <div class="menu-card">
            <div class="m-bottom2"><a href="' . get_the_permalink() . '">';
			$output .= get_the_post_thumbnail( $post->ID, $image_size, array(
				'title'	 => $props['title'],
				'alt'    => $props['alt'],
			) );
			$output .= '</a></div>
            ';
			return $output;
		} elseif ( wc_placeholder_img_src() ) {
			return wc_placeholder_img( $image_size );
		}
	}
 }
 
// **********************************************************************// 
// ! Customizing pricing of product loop
// **********************************************************************//
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10);
add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
/**
 * WooCommerce Loop Product Pricing
 **/
	function woocommerce_template_loop_price() {
		global $product;

			echo '<div class="menu-items">
              <h3 class="font-bold font-black text-center"><a href="' . get_the_permalink() . '">' . $product->get_title() . '</a></h3>
				<span class="price text-left">' . $product->get_price_html() . '</span>
              <div class="dotted-lines"></div>
            </div>';
	}

// **********************************************************************// 
// ! Customizing category product of loop
// **********************************************************************//
 remove_action( 'woocommerce_shop_loop_subcategory_title', 'woocommerce_template_loop_category_title', 10 );
 
 add_action( 'woocommerce_shop_loop_subcategory_title', 'woocommerce_template_loop_category_title', 10 );
 function woocommerce_template_loop_category_title( $category ) {
 ?>
		<div class="menu-items">
			<h3 class="font-bold font-black text-center">
			<a href="<?php echo get_term_link( $category, 'product_cat' ); ?>"><?php echo esc_attr( $category->name ); ?><?php if ( $category->count > 0 )
								echo apply_filters( 'woocommerce_subcategory_count_html', ' <span class="count padding_point2">(' . $category->count . ')</span>', $category ); ?></a>
			</h3>
			<div class="dotted-lines"></div>
		</div>
		<p class="nodisplay"><?php echo wp_html_excerpt (($category->description), 60); ?></p>
		<div class="button full-wid left m-top2 text-center"><a href="<?php echo get_term_link( $category, 'product_cat' ); ?>" class="btn boxed-color-xs uppercase font-bold"><?php esc_html_e('View Details', 'depilex'); ?></a></div>
<?php
}

// **********************************************************************// 
// ! Customizing single product rating position
// **********************************************************************//
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 30 );

// **********************************************************************// 
// ! Customizing woocommerce breadcrumb
// **********************************************************************//
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
add_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
function woocommerce_breadcrumb( $args = array() ) {
	$args = wp_parse_args( $args, apply_filters( 'woocommerce_breadcrumb_defaults', array(
			'delimiter'   => '<span>/</span>',
			'wrap_before' => '',
			'wrap_after'  => '',
			'before'      => '',
			'after'       => '',
			'home'        => _x( 'Home', 'breadcrumb', 'depilex' )
		) ) );

		$breadcrumbs = new WC_Breadcrumb();

		if ( ! empty( $args['home'] ) ) {
			$breadcrumbs->add_crumb( $args['home'], apply_filters( 'woocommerce_breadcrumb_home_url', home_url() ) );
		}

		$args['breadcrumb'] = $breadcrumbs->generate();

		wc_get_template( 'global/breadcrumb.php', $args );
}

// **********************************************************************// 
// ! Register WooCommerce Sidebars
// **********************************************************************//
if ( ! function_exists( 'depilex_woocommerce_widgets_init' ) ) {
	function depilex_woocommerce_widgets_init() {

		register_sidebar( array(
		'name' => esc_html__( 'WooCommerce Sidebar', 'depilex' ),
		'id' => 'depilex_woocommerce_sidebar',
		'before_widget' => '<div id="%1$s" class="widget widget__sidebar %2$s">',
		'after_widget' => '</div><div class="clearfix"></div>',
		'before_title' => '<h2>',
		'after_title' => '</h2>',
	) );
	}
}
add_action( 'widgets_init', 'depilex_woocommerce_widgets_init' );

// **********************************************************************// 
// ! Change number or products per row to 3
// **********************************************************************//
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
	function loop_columns() {
		return 3; // 3 products per row
	}
}

// **********************************************************************// 
// ! Change number or products for related proeucts
// **********************************************************************//
if ( ! function_exists( 'woocommerce_output_related_products' ) ) {
function woocommerce_output_related_products() {
woocommerce_related_products(3,3);   // Display 3 products in 3 columns
}
}
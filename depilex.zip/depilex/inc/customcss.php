<?php
function depilex_styles_custom() {
$depilex_page_id_for_posts = get_option( 'page_for_posts' );
global $wp_query;
$postid = $wp_query->post->ID;
if ( is_home() ) {
$header_styles = get_post_meta($depilex_page_id_for_posts, 'header_key', true);
} else {
$header_styles = get_post_meta($postid, 'header_key', true);
}
?>
<!-- Custom CSS Codes
========================================================= -->
<style id="custom-style">
	<?php if( $header_styles == 'style_two' ) { ?>
		.header-area .logo-bar .info-box .icon{ color: #333 !important; }
		.header-area .logo-bar{ background-color: #fff !important; }
	<?php } ?>
	<?php if( $header_styles == 'style_four' ) { ?>
	@media (max-width: 767px) {
	.navbar-default.transparent .navbar-nav>li>a 
	{
		color:#000 !important;
	}
	}
	<?php } ?>
	<?php //Color CSS Styles ?>
	<?php if(depilex_get_option('custom_color') != '') { //Global color start ?>
	.service-post-container .heading-overlay {
	background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.team-overlay-down {
	background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.team-img-container:hover .team-overlay {
	background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.opening-hour-grid {
	background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.blog-overlay {
	background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.blog-overlay-down {
	background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.heading, .calendar_wrap a {
	color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.calendar_wrap a:hover {
	color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.navbar-default .active {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.btn-primary:hover, .btn-primary:focus, .btn-primary.focus, .btn-primary:active, .btn-primary.active, .open>.dropdown-toggle.btn-primary, .btn-light-solid:hover, .btn-light-solid:focus, .btn-light-solid:active, .btn-light-solid:visited {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		border-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.btn-colored, .scrollup {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.btn-clean:hover {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		border: 1px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.btn-dark:hover, .btn-dark:active, .btn-dark:focus, .btn-dark:visited {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		border-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	.bredcrumbs a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.bredcrumbs a:last-child {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.top-bar {
		border-bottom: 1px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.appoinment-button:hover {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0 !important;
	}
	.navigation .dropdown-menu, .navigation-2 .dropdown-menu {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.navbar-top-2 {
		border-top: 3px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.navbar-link-2 ul li a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>
	}
	.header-content .btn-link:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	/********** menu hover css ********/
	.navigation-2 .navbar-default .navbar-nav>li>a:focus, .navigation-2 .navbar-default .navbar-nav>li>a:hover {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	/********* menu hover 0pen css ********/
	.navigation-2 .navbar-default .navbar-nav>.open>a, .navigation-2 .navbar-default .navbar-nav>.open>a:focus, .navigation-2 .navbar-default .navbar-nav>.open>a:hover {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.navigation-2 .navbar-default .navbar-toggle .icon-bar {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.tt-slider-title.dark {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.tt-slider-subtitle.dark {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.btn-solid.light {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.btn-solid.light:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.btn-bordered.light:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.our-services h4:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.services-content h4:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.our-services h4 a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.services-content h4 a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.team-overlay a:hover {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0;
		border-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	ul#filter.filter-square li:hover {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		border: 1px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	ul#filter.filter-square li.active {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	ul#filter.filter-transparent li.active {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.portfolio:hover .portfolio-info .links {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.portfolio-info .btn:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.portfolio:hover .portfolio-details li {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.portfolio-details li a {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	ul.project-meta li a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.project-link {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.portfolio-version-two .project-link ul li a {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		border: 2px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;	
	}
	.portfolio-version-two .project-link ul li a:hover {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.info a.like i, .info a.like:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.portfolio:hover .portfolio-details li {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.portfolio-details li a {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.control-two:hover .carousel-control:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.portfolio-nav a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.portfolio-meta li a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.work-timings li.hour-time {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0;
	}
	.price_title a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.price_right {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.choose-box-content h4 a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.carousel-indicators .active {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	.btn-blog {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		border: 1px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.btn-blog:hover {
		background: #363636;
		border: 1px solid #363636;
	}
	.post-content h2 a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.post-block blockquote {
		border-left: 5px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.post-block blockquote.left-quote {
		border-left: 5px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.meta-bg {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.meta-link:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.meta-comment i, .meta-author i, .meta-tag i {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	#slider .owl-prev, #slider .owl-next, #post-slider .owl-next, #post-slider .owl-prev {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.side-bar .widget h2 {
		border-left: 4px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.side-bar .widget ul li a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.side-bar .widget .tag_cloud a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.tag_cloud a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.related-grid-name > span:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.related-grid-name > h5:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.media-heading a {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.media-heading a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.comment-reply-link {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	.custom-pagination li a:hover, .custom-pagination li a.active {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0;
		border-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.footer-social ul li a:hover {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0;
	}
	.inner-footer .post ul li a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.inner-footer .contact ul li:hover, .inner-footer .contact ul li:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.newsletter form .btn:hover {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0;
		border: 1px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.sub-footer {
		border-bottom: 4px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.footer-menu ul li a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.commingsoon .newsletter form .btn:hover {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0 !important;
		border: 1px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	.maintenance-container h1 {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.maintenance-container .btn {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.maintenance-container .btn:hover {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0;
		border-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.error-container h1 {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.error-container .btn {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.error-container .btn:hover {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0;
		border-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	@media (min-width: 320px) and (max-width: 767px) {
	.navigation .navbar-default .navbar-collapse, .navbar-default .navbar-form {
		border-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	}
	@media only screen and (max-width: 767px) {
	.navigation-2 .navbar-default .navbar-collapse, .navbar-default .navbar-form {
		border-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.navigation .navbar-default .navbar-toggle {
		 border: 1px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		 background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	}
	/*Using #363636 Color*/
	#slider .owl-prev:hover, #slider .owl-next:hover, #post-slider .owl-next:hover, #post-slider .owl-prev:hover {
		background-color: #363636;
	}
	.social-icons ul li a:hover {
		background: #363636 none repeat scroll 0 0;
	}
	.header-content .call-number i {
		color: #363636;
	}
	/*Using #363636 Color End*/
	
	.btn-bordered.dark:hover {
	background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.slider-caption .btn:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.team-image ul.social-icons li a:hover {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0;
	}
	 .pricing-grid:hover .btn:hover,  .pricing-grid.active .btn:hover {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>  none repeat scroll 0 0;
		border-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> ;
	}
	.service-tab li.active i::before, .service-tab li:hover i::before {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.service-tab li.active::after, .service-tab li:hover::after {
		border-bottom: 10px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.services-section h2::after {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	@media (min-width: 320px) and (max-width: 767px) {
	.navigation .navbar-default.transparent {
		border-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	.navigation .navbar-default {
		border-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	.navigation .dropdown-menu>li>a:hover {
		color: #fff !important;
	}
	.navigation .navbar-default.transparent .dropdown-menu>li>a:hover{
		color: #333 !important;
	}
	}
	<?php if( ( $header_styles == 'style_four' ) || ( $header_styles == 'style_three' ) ){ ?>
	/*header-two-css*/
	@media (min-width: 768px) {
	.container>.navbar-header {
		display: block;
	}
	}
	@media all and (min-width: 768px) and (max-width: 991px) {
	.top-bar {
		border-bottom: 1px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	}
	.appoinment-button:hover {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0 !important;
	}
	.navigation .navbar-default .navbar-nav>.open>a, .navigation .navbar-default .navbar-nav>.open>a:focus, .navigation .navbar-default .navbar-nav>.open>a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.navigation .navbar-default .navbar-nav>li>a:focus, .navigation .navbar-default .navbar-nav>li>a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	@media (max-width: 767px) {
	/********** menu hover css ********/
		.navigation .navbar-default .navbar-nav>li>a:focus, .navigation .navbar-default .navbar-nav>li>a:hover {
			background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		}
	/********* menu hover 0pen css ********/
		.navigation .navbar-default .navbar-nav>.open>a, .navigation .navbar-default .navbar-nav>.open>a:focus, .navigation .navbar-default .navbar-nav>.open>a:hover {
			background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		}
		/*** menu hover css ***/
	.navigation .navbar-default .navbar-nav>li>a:focus, .navigation .navbar-default .navbar-nav>li>a:hover {
		color: #fff;
	}
	/*** menu hover 0pen css ***/
	.navigation .navbar-default .navbar-nav>.open>a, .navigation .navbar-default .navbar-nav>.open>a:focus, .navigation .navbar-default .navbar-nav>.open>a:hover {
		color: #fff;
	}
	}
	.navigation .dropdown-menu, .navigation-2 .dropdown-menu {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.navbar-top-2 {
		border-top: 3px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.navbar-link-2 ul li a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>
	}
	.header-content .btn-link:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.navigation-2 .navbar-default .navbar-nav>li>a:focus, .navigation-2 .navbar-default .navbar-nav>li>a:hover {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.navigation-2 .navbar-default .navbar-nav>.open>a, .navigation-2 .navbar-default .navbar-nav>.open>a:focus, .navigation-2 .navbar-default .navbar-nav>.open>a:hover {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.navigation-2 .navbar-default .navbar-toggle .icon-bar {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	/*Using #363636 Color*/
	.social-icons ul li a:hover {
	background: #363636 none repeat scroll 0 0;
	}
	.header-content .call-number i {
	color: #363636;
	}
	/*Using #363636 Color End*/
	<?php } ?>
	.type-post a:hover {
    color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.custom-pagination li a:hover, .custom-pagination li a.current {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0;
		border-color: #363636;
		color: #ffffff;
	}
	.side-bar .widget .tagcloud a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.tagcloud a:hover {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.page-template-page-no-bg .page-heading.breadcrumb-image{
	background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	/*Using #363636 Color*/
		.custom-pagination li a:hover, .custom-pagination li a.current {
		border-color: #363636;
	}
		/*Using #363636 Color End*/
	<?php if( $header_styles == 'style_four' ) { ?>
	@media (max-width: 767px) {
	.navbar-default.transparent .navbar-nav>li>a:focus, .navbar-default.transparent .navbar-nav>li>a:hover{
		color:#fff !important;
	}
	}
	<?php } ?>
	<?php if ( class_exists( 'woocommerce' ) ) { ?>
/*New for WooCommerce*/
	.button-shop, .wc-forward, .woocommerce .return-to-shop .button.wc-backward, .woocommerce .login .button, .comment-form .form-submit .button{
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		border: 1px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		color: #fff;
	}

	.button-shop:hover, .wc-forward:hover, .woocommerce .return-to-shop .button.wc-backward:hover, .woocommerce .login .button:hover, .comment-form .form-submit .button:hover {
		background: #222;
		color: #fff;
		border: 1px solid #222;
	}
	
	.pricing-action .add_to_cart_button, .button.full-wid .boxed-color-xs, .pricing-action .product_type_simple, .pricing-action .product_type_variable,
	.woo-sidebar .price_slider_amount button, .woo-sidebar p.buttons a{
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	
	.pricing-action .add_to_cart_button:hover, .button.full-wid .boxed-color-xs:hover, .pricing-action .product_type_simple:hover, .pricing-action .product_type_variable:hover,
	.woo-sidebar .price_slider_amount button:hover, .woo-sidebar p.buttons a:hover{
		background-color: #363636 !important;
	}

	.dlink, .zoom, .posted_in a, .tagged_as a, .sku {
	  color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	
	.posted_in a:hover, .tagged_as a:hover, .sku:hover {
	  color: #363636 !important;
	}
	
	.dlink:hover, .zoom:hover {
	  color: #fff !important;
	  background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}

	.products .product .onsale {
	  background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}

	.pagination-button {
	  padding: 10px !important;
	  color: #fff !important;
	  background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	  border: none;
	}

	.amount {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}

	.star-rating span {
	  color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}

	.shop-page .list ul li:before {
	  position: relative;
		top: 0;
		left: 0;
		content: "\f0da";
		font-family: 'FontAwesome';
		font-size: 14px;
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		margin-right: 10px;
		font-style: normal;
		font-weight: normal;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
	}

	/* Shop */
	.pagination-custom .pagination-button:hover {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		border-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.single-prodcut .tabs .nav-tabs > li.active > a, 
	.tabbed-widget .tabs .nav-tabs > li.active > a,
	.shop-with-sidebar .widget .title > a,
	.shopping-cart .cart-table tbody > tr > td > a,
	.shop-checkout .cart-table a,
	.shop-checkout .panel-group .panel-body label span,
	.page-shop-login label span {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.single-prodcut .tabs .nav-tabs > li.active > a:after,
	.tabbed-widget .tabs .nav-tabs > li.active > a:after
	.shop-checkout .panel-group .panel-title > a {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.woocommerce-message .button.wc-forward{
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0;
	}
	.summary.entry-summary ul li:before, .woocommerce-tabs.wc-tabs-wrapper ul li:before {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.woocommerce div.product form.cart .button, .coupon input.button, .checkout_coupon input.button, .login input.button, .login input.button:hover,
	.cart .actions input.button, .woocommerce div.product form.cart .button:hover, .coupon input.button:hover, .checkout_coupon input.button:hover,
	.cart .actions input.button:hover, #review_form footer button, .woocommerce-tabs ul.tabs li.active, .woocommerce-tabs ul.tabs li:hover,
	.woocommerce .product ul.tabs li.active a, .woocommerce .product ul.tabs li:hover a, .tags li a:hover, .tagcloud a:hover{
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.pagination-button {
	  background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.dlink, .zoom {
	  color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	.dlink:hover, .zoom:hover {
	  background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	.products .product .onsale {
	  background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	.amount {
	  color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	.star-rating span {
	  color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	.list ul li:before {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.button-shop {
		background: <?php echo esc_html( depilex_get_option('custom_color') ); ?> none repeat scroll 0 0;
		border: 1px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.pagination-custom .pagination-button:hover {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
		border-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.shop-with-sidebar .widget .title > a {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.single-prodcut .tabs .nav-tabs > li.active > a:after,
	.tabbed-widget .tabs .nav-tabs > li.active > a:after {
	  background: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.single-prodcut .tabs .nav-tabs > li.active > a,
	.tabbed-widget .tabs .nav-tabs > li.active > a {
	  color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.shopping-cart .cart-table tbody > tr > td > a {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.shop-checkout .panel-group .panel-title > a  {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.shop-checkout .cart-table a {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.shop-checkout .panel-group .panel-body label span {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.page-shop-login label span {
		color: <?php echo esc_html( depilex_get_option('custom_color') ); ?>;
	}
	.woocommerce .widget_price_filter .ui-slider .ui-slider-range, .woocommerce .widget_price_filter .ui-slider .ui-slider-handle {
		background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	.woocommerce .menu-card:hover{
		border: 1px solid <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	.woocommerce .page-heading.breadcrumb-image{
	background-color: <?php echo esc_html( depilex_get_option('custom_color') ); ?> !important;
	}
	<?php } ?>
	<?php } else { ?>
	.service-post-container .heading-overlay {
	background: #F9A392;
	}
	.team-overlay-down {
	background: #F9A392;
	}
	.team-img-container:hover .team-overlay {
	background-color: #F9A392;
	}
	.opening-hour-grid {
	background: #F9A392;
	}
	.blog-overlay {
	background: #F9A392;
	}
	.blog-overlay-down {
	background: #F9A392;
	}
	.heading, .calendar_wrap a {
	color: #F9A392;
	}
	.calendar_wrap a:hover {
	color: #FF8D00;
	}
	.navbar-default .active {
		background: #F9A392;
	}
	.btn-primary:hover, .btn-primary:focus, .btn-primary.focus, .btn-primary:active, .btn-primary.active, .open>.dropdown-toggle.btn-primary, .btn-light-solid:hover, .btn-light-solid:focus, .btn-light-solid:active, .btn-light-solid:visited {
		background-color: #F9A392;
		border-color: #F9A392;
	}
	.btn-colored, .scrollup {
		background-color: #F9A392;
	}
	.btn-clean:hover {
		background-color: #F9A392;
		border: 1px solid #F9A392;
	}
	.btn-dark:hover, .btn-dark:active, .btn-dark:focus, .btn-dark:visited {
		background: #F9A392;
		border-color: #F9A392 !important;
	}
	.bredcrumbs a:hover {
		color: #F9A392;
	}
	.bredcrumbs a:last-child {
		color: #F9A392;
	}
	.top-bar {
		border-bottom: 1px solid #F9A392;
		background: #F9A392;
	}
	.appoinment-button:hover {
		background: #F9A392 none repeat scroll 0 0 !important;
	}
	.navigation .dropdown-menu, .navigation-2 .dropdown-menu {
		background-color: #F9A392;
	}
	.navbar-top-2 {
		border-top: 3px solid #F9A392;
	}
	.navbar-link-2 ul li a:hover {
		color: #F9A392
	}
	.header-content .btn-link:hover {
		color: #F9A392;
	}
	/********** menu hover css ********/
	.navigation-2 .navbar-default .navbar-nav>li>a:focus, .navigation-2 .navbar-default .navbar-nav>li>a:hover {
		background-color: #F9A392;
	}
	/********* menu hover 0pen css ********/
	.navigation-2 .navbar-default .navbar-nav>.open>a, .navigation-2 .navbar-default .navbar-nav>.open>a:focus, .navigation-2 .navbar-default .navbar-nav>.open>a:hover {
		background-color: #F9A392;
	}
	.navigation-2 .navbar-default .navbar-toggle .icon-bar {
		background-color: #F9A392;
	}
	.tt-slider-title.dark {
		color: #F9A392;
	}
	.tt-slider-subtitle.dark {
		color: #F9A392;
	}
	.btn-solid.light {
		color: #F9A392;
	}
	.btn-solid.light:hover {
		color: #F9A392;
	}
	.btn-bordered.light:hover {
		color: #F9A392;
	}
	.our-services h4:hover {
		color: #F9A392;
	}
	.services-content h4:hover {
		color: #F9A392;
	}
	.our-services h4 a:hover {
		color: #F9A392;
	}
	.services-content h4 a:hover {
		color: #F9A392;
	}
	.team-overlay a:hover {
		background: #F9A392 none repeat scroll 0 0;
		border-color: #F9A392;
	}
	ul#filter.filter-square li:hover {
		background-color: #F9A392;
		border: 1px solid #F9A392;
	}
	ul#filter.filter-square li.active {
		background-color: #F9A392;
	}
	ul#filter.filter-transparent li.active {
		color: #F9A392;
	}
	.portfolio:hover .portfolio-info .links {
		color: #F9A392;
	}
	.portfolio-info .btn:hover {
		color: #F9A392;
	}
	.portfolio:hover .portfolio-details li {
		color: #F9A392;
	}
	.portfolio-details li a {
		background-color: #F9A392;
	}
	ul.project-meta li a:hover {
		color: #F9A392;
	}
	.project-link {
		background: #F9A392;
	}
	.portfolio-version-two .project-link ul li a {
		color: #F9A392;
		border: 2px solid #F9A392;	
	}
	.portfolio-version-two .project-link ul li a:hover {
		background-color: #F9A392;
	}
	.info a.like i, .info a.like:hover {
		color: #F9A392;
	}
	.portfolio:hover .portfolio-details li {
		color: #F9A392;
	}
	.portfolio-details li a {
		background-color: #F9A392;
	}
	.control-two:hover .carousel-control:hover {
		color: #F9A392;
	}
	.portfolio-nav a:hover {
		color: #F9A392;
	}
	.portfolio-meta li a:hover {
		color: #F9A392;
	}
	.work-timings li.hour-time {
		background: #F9A392 none repeat scroll 0 0;
	}
	.price_title a:hover {
		color: #F9A392;
	}
	.price_right {
		color: #F9A392;
	}
	.choose-box-content h4 a:hover {
		color: #F9A392;
	}
	.carousel-indicators .active {
		color: #F9A392 !important;
		background-color: #F9A392 !important;
	}
	.btn-blog {
		background: #F9A392;
		border: 1px solid #F9A392;
	}
	.btn-blog:hover {
		background: #363636;
		border: 1px solid #363636;
	}
	.post-content h2 a:hover {
		color: #F9A392;
	}
	.post-block blockquote {
		border-left: 5px solid #F9A392;
	}
	.post-block blockquote.left-quote {
		border-left: 5px solid #F9A392;
	}
	.meta-bg {
		background-color: #F9A392;
	}
	.meta-link:hover {
		color: #F9A392;
	}
	.meta-comment i, .meta-author i, .meta-tag i {
		color: #F9A392;
	}
	#slider .owl-prev, #slider .owl-next, #post-slider .owl-next, #post-slider .owl-prev {
		background-color: #F9A392;
	}
	.side-bar .widget h2 {
		border-left: 4px solid #F9A392;
	}
	.side-bar .widget ul li a:hover {
		color: #F9A392;
	}
	.side-bar .widget .tag_cloud a:hover {
		color: #F9A392;
	}
	.tag_cloud a:hover {
		color: #F9A392;
	}
	.related-grid-name > span:hover {
		color: #F9A392;
	}
	.related-grid-name > h5:hover {
		color: #F9A392;
	}
	.media-heading a {
		color: #F9A392;
	}
	.media-heading a:hover {
		color: #F9A392;
	}
	.comment-reply-link {
		color: #F9A392 !important;
	}
	.custom-pagination li a:hover, .custom-pagination li a.active {
		background: #F9A392 none repeat scroll 0 0;
		border-color: #F9A392;
	}
	.footer-social ul li a:hover {
		background: #F9A392 none repeat scroll 0 0;
	}
	.inner-footer .post ul li a:hover {
		color: #F9A392;
	}
	.inner-footer .contact ul li:hover, .inner-footer .contact ul li:hover {
		color: #F9A392;
	}
	.newsletter form .btn:hover {
		background: #F9A392 none repeat scroll 0 0;
		border: 1px solid #F9A392;
	}
	.sub-footer {
		border-bottom: 4px solid #F9A392;
	}
	.footer-menu ul li a:hover {
		color: #F9A392;
	}
	.commingsoon .newsletter form .btn:hover {
		background: #F9A392 none repeat scroll 0 0 !important;
		border: 1px solid #F9A392 !important;
	}
	.maintenance-container h1 {
		color: #F9A392;
	}
	.maintenance-container .btn {
		color: #F9A392;
	}
	.maintenance-container .btn:hover {
		background: #F9A392 none repeat scroll 0 0;
		border-color: #F9A392;
	}
	.error-container h1 {
		color: #F9A392;
	}
	.error-container .btn {
		color: #F9A392;
	}
	.error-container .btn:hover {
		background: #F9A392 none repeat scroll 0 0;
		border-color: #F9A392;
	}
	@media (min-width: 320px) and (max-width: 767px) {
	.navigation .navbar-default .navbar-collapse, .navbar-default .navbar-form {
		border-color: #F9A392 !important;
	}
	}
	@media only screen and (max-width: 767px) {
	.navigation-2 .navbar-default .navbar-collapse, .navbar-default .navbar-form {
		border-color: #F9A392;
	}
	.navigation .navbar-default .navbar-toggle {
		 border: 1px solid #F9A392;
		 background-color: #F9A392;
	}
	}
	/*Using #c09f57 Color*/
	#slider .owl-prev:hover, #slider .owl-next:hover, #post-slider .owl-next:hover, #post-slider .owl-prev:hover {
		background-color: #c09f57;
	}
	.social-icons ul li a:hover {
		background: #c09f57 none repeat scroll 0 0;
	}
	.header-content .call-number i {
		color: #c09f57;
	}
	/*Using #c09f57 Color End*/
	
	.btn-bordered.dark:hover {
	background-color: #F9A392;
	}
	.slider-caption .btn:hover {
		color: #F9A392;
	}
	.team-image ul.social-icons li a:hover {
		background: #F9A392 none repeat scroll 0 0;
	}
	 .pricing-grid:hover .btn:hover,  .pricing-grid.active .btn:hover {
		background: #F9A392  none repeat scroll 0 0;
		border-color: #F9A392 ;
	}
	.service-tab li.active i::before, .service-tab li:hover i::before {
		color: #F9A392;
	}
	.service-tab li.active::after, .service-tab li:hover::after {
		border-bottom: 10px solid #F9A392;
	}
	.services-section h2::after {
		background-color: #F9A392;
	}
	@media (min-width: 320px) and (max-width: 767px) {
	.navigation .navbar-default.transparent {
		border-color: #F9A392 !important;
	}
	.navigation .navbar-default {
		border-color: #F9A392 !important;
	}
	.navigation .dropdown-menu>li>a:hover {
		color: #fff !important;
	}
	.navigation .navbar-default.transparent .dropdown-menu>li>a:hover{
		color: #333 !important;
	}
	}
	<?php if( ( $header_styles == 'style_four' ) || ( $header_styles == 'style_three' ) ){ ?>
	/*header-two-css*/
	@media (min-width: 768px) {
	.container>.navbar-header {
		display: block;
	}
	}
	@media all and (min-width: 768px) and (max-width: 991px) {
	.top-bar {
		border-bottom: 1px solid #F9A392;
		background: #F9A392;
	}
	}
	.appoinment-button:hover {
		background: #F9A392 none repeat scroll 0 0 !important;
	}
	.navigation .navbar-default .navbar-nav>.open>a, .navigation .navbar-default .navbar-nav>.open>a:focus, .navigation .navbar-default .navbar-nav>.open>a:hover {
		color: #F9A392;
	}
	.navigation .navbar-default .navbar-nav>li>a:focus, .navigation .navbar-default .navbar-nav>li>a:hover {
		color: #F9A392;
	}
	@media (max-width: 767px) {
	/********** menu hover css ********/
		.navigation .navbar-default .navbar-nav>li>a:focus, .navigation .navbar-default .navbar-nav>li>a:hover {
			background-color: #F9A392;
		}
	/********* menu hover 0pen css ********/
		.navigation .navbar-default .navbar-nav>.open>a, .navigation .navbar-default .navbar-nav>.open>a:focus, .navigation .navbar-default .navbar-nav>.open>a:hover {
			background-color: #F9A392;
		}
		/*** menu hover css ***/
	.navigation .navbar-default .navbar-nav>li>a:focus, .navigation .navbar-default .navbar-nav>li>a:hover {
		color: #fff;
	}
	/*** menu hover 0pen css ***/
	.navigation .navbar-default .navbar-nav>.open>a, .navigation .navbar-default .navbar-nav>.open>a:focus, .navigation .navbar-default .navbar-nav>.open>a:hover {
		color: #fff;
	}
	.navigation .dropdown-menu>li>a:hover {
		color: #fff !important;
	}
	.navigation .navbar-default.transparent .dropdown-menu>li>a:hover{
		color: #333 !important;
	}
	}
	.navigation .dropdown-menu, .navigation-2 .dropdown-menu {
		background-color: #F9A392;
	}
	.navbar-top-2 {
		border-top: 3px solid #F9A392;
	}
	.navbar-link-2 ul li a:hover {
		color: #F9A392
	}
	.header-content .btn-link:hover {
		color: #F9A392;
	}
	.navigation-2 .navbar-default .navbar-nav>li>a:focus, .navigation-2 .navbar-default .navbar-nav>li>a:hover {
		background-color: #F9A392;
	}
	.navigation-2 .navbar-default .navbar-nav>.open>a, .navigation-2 .navbar-default .navbar-nav>.open>a:focus, .navigation-2 .navbar-default .navbar-nav>.open>a:hover {
		background-color: #F9A392;
	}
	.navigation-2 .navbar-default .navbar-toggle .icon-bar {
		background-color: #F9A392;
	}
	/*Using #c09f57 Color*/
	.social-icons ul li a:hover {
	background: #c09f57 none repeat scroll 0 0;
	}
	.header-content .call-number i {
	color: #c09f57;
	}
	/*Using #c09f57 Color End*/
	<?php } ?>
	.type-post a:hover {
    color: #F9A392;
	}
	.custom-pagination li a:hover, .custom-pagination li a.current {
		background: #F9A392 none repeat scroll 0 0;
		border-color: #c09f57;
		color: #ffffff;
	}
	.side-bar .widget .tagcloud a:hover {
		color: #F9A392;
	}
	.tagcloud a:hover {
		color: #F9A392;
	}
	.page-template-page-no-bg .page-heading.breadcrumb-image{
	background-color: #F9A392 !important;
	}
	/*Using #c09f57 Color*/
		.custom-pagination li a:hover, .custom-pagination li a.current {
		border-color: #c09f57;
	}
		/*Using #c09f57 Color End*/
	<?php if( $header_styles == 'style_four' ) { ?>
	@media (max-width: 767px) {
	.navbar-default.transparent .navbar-nav>li>a:focus, .navbar-default.transparent .navbar-nav>li>a:hover{
		color:#fff !important;
	}
	}
	<?php } ?>
	<?php if ( class_exists( 'woocommerce' ) ) { ?>
/*New for WooCommerce*/
	.button-shop, .wc-forward, .woocommerce .return-to-shop .button.wc-backward, .woocommerce .login .button, .comment-form .form-submit .button{
		background: #F9A392;
		border: 1px solid #F9A392;
		color: #fff;
	}

	.button-shop:hover, .wc-forward:hover, .woocommerce .return-to-shop .button.wc-backward:hover, .woocommerce .login .button:hover, .comment-form .form-submit .button:hover {
		background: #222;
		color: #fff;
		border: 1px solid #222;
	}
	
	.pricing-action .add_to_cart_button, .button.full-wid .boxed-color-xs, .pricing-action .product_type_simple, .pricing-action .product_type_variable,
	.woo-sidebar .price_slider_amount button, .woo-sidebar p.buttons a{
		background-color: #F9A392 !important;
	}
	
	.pricing-action .add_to_cart_button:hover, .button.full-wid .boxed-color-xs:hover, .pricing-action .product_type_simple:hover, .pricing-action .product_type_variable:hover,
	.woo-sidebar .price_slider_amount button:hover, .woo-sidebar p.buttons a:hover{
		background-color: #363636 !important;
	}

	.dlink, .zoom, .posted_in a, .tagged_as a, .sku {
	  color: #F9A392 !important;
	}
	
	.posted_in a:hover, .tagged_as a:hover, .sku:hover {
	  color: #363636 !important;
	}
	
	.dlink:hover, .zoom:hover {
	  color: #fff !important;
	  background-color: #F9A392 !important;
	}

	.products .product .onsale {
	  background: #F9A392 !important;
	}

	.pagination-button {
	  padding: 10px !important;
	  color: #fff !important;
	  background-color: #F9A392;
	  border: none;
	}

	.amount {
		color: #F9A392 !important;
	}

	.star-rating span {
	  color: #F9A392 !important;
	}

	.shop-page .list ul li:before {
	  position: relative;
		top: 0;
		left: 0;
		content: "\f0da";
		font-family: 'FontAwesome';
		font-size: 14px;
		color: #F9A392;
		margin-right: 10px;
		font-style: normal;
		font-weight: normal;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
	}

	/* Shop */
	.pagination-custom .pagination-button:hover {
		background-color: #F9A392;
		border-color: #F9A392;
	}
	.single-prodcut .tabs .nav-tabs > li.active > a, 
	.tabbed-widget .tabs .nav-tabs > li.active > a,
	.shop-with-sidebar .widget .title > a,
	.shopping-cart .cart-table tbody > tr > td > a,
	.shop-checkout .cart-table a,
	.shop-checkout .panel-group .panel-body label span,
	.page-shop-login label span {
		color: #F9A392;
	}
	.single-prodcut .tabs .nav-tabs > li.active > a:after,
	.tabbed-widget .tabs .nav-tabs > li.active > a:after
	.shop-checkout .panel-group .panel-title > a {
		background-color: #F9A392;
	}
	.woocommerce-message .button.wc-forward{
		background: #F9A392 none repeat scroll 0 0;
	}
	.summary.entry-summary ul li:before, .woocommerce-tabs.wc-tabs-wrapper ul li:before {
		color: #F9A392;
	}
	.woocommerce div.product form.cart .button, .coupon input.button, .checkout_coupon input.button, .login input.button, .login input.button:hover,
	.cart .actions input.button, .woocommerce div.product form.cart .button:hover, .coupon input.button:hover, .checkout_coupon input.button:hover,
	.cart .actions input.button:hover, #review_form footer button, .woocommerce-tabs ul.tabs li.active, .woocommerce-tabs ul.tabs li:hover,
	.woocommerce .product ul.tabs li.active a, .woocommerce .product ul.tabs li:hover a, .tags li a:hover, .tagcloud a:hover{
		background-color: #F9A392;
	}
	.pagination-button {
	  background-color: #F9A392;
	}
	.dlink, .zoom {
	  color: #F9A392 !important;
	}
	.dlink:hover, .zoom:hover {
	  background-color: #F9A392 !important;
	}
	.products .product .onsale {
	  background: #F9A392 !important;
	}
	.amount {
	  color: #F9A392 !important;
	}
	.star-rating span {
	  color: #F9A392 !important;
	}
	.list ul li:before {
		color: #F9A392;
	}
	.button-shop {
		background: #F9A392 none repeat scroll 0 0;
		border: 1px solid #F9A392;
	}
	.pagination-custom .pagination-button:hover {
		background-color: #F9A392;
		border-color: #F9A392;
	}
	.shop-with-sidebar .widget .title > a {
		color: #F9A392;
	}
	.single-prodcut .tabs .nav-tabs > li.active > a:after,
	.tabbed-widget .tabs .nav-tabs > li.active > a:after {
	  background: #F9A392;
	}
	.single-prodcut .tabs .nav-tabs > li.active > a,
	.tabbed-widget .tabs .nav-tabs > li.active > a {
	  color: #F9A392;
	}
	.shopping-cart .cart-table tbody > tr > td > a {
		color: #F9A392;
	}
	.shop-checkout .panel-group .panel-title > a  {
		background-color: #F9A392;
	}
	.shop-checkout .cart-table a {
		color: #F9A392;
	}
	.shop-checkout .panel-group .panel-body label span {
		color: #F9A392;
	}
	.page-shop-login label span {
		color: #F9A392;
	}
	.woocommerce .widget_price_filter .ui-slider .ui-slider-range, .woocommerce .widget_price_filter .ui-slider .ui-slider-handle {
		background-color: #F9A392 !important;
	}
	.woocommerce .menu-card:hover{
	border: 1px solid #F9A392 !important;
	}
	.woocommerce .page-heading.breadcrumb-image{
	background-color: #F9A392 !important;
	}
	<?php } ?>
	<?php } ?>
	<?php echo esc_textarea( depilex_get_option('textarea_csscode') ); //Load Custom CSS from Theme-Options ?>
	
</style>

<?php }
add_action( 'wp_head', 'depilex_styles_custom', 100 );
?>
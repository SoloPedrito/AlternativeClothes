<?php
function depilex_scripts_basic() {  

	/* ------------------------------------------------------------------------ */
	/* Enqueue Scripts */
	/* ------------------------------------------------------------------------ */
	/* Pre-Loader */
	if(depilex_get_option('depilex_preloader') == '1') {
	wp_enqueue_script('depilex-pre-loader', get_template_directory_uri() . '/js/pageloader.js', array( 'jquery' ), '1.0.0', true);
	}
	/* Form Validation */
	wp_enqueue_script('jquery.validate.min.js', get_template_directory_uri() . '/js/jquery.validate.min.js', array( 'jquery' ), '1.0.0', true);
	/* Bootstrap */
	wp_enqueue_script('bootstrap.min.js', get_template_directory_uri() . '/js/bootstrap.min.js', array( 'jquery' ), '1.0.0', true);
	/* Cubeportfolio */
	wp_enqueue_script('jquery.smoothscroll.js', get_template_directory_uri() . '/js/jquery.smoothscroll.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('jquery.easing.js', get_template_directory_uri() . '/js/easing.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('jquery.stellar.min.js', get_template_directory_uri() . '/js/jquery.stellar.min.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('jquery.countTo.js', get_template_directory_uri() . '/js/jquery.countTo.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('jquery.waypoints.js', get_template_directory_uri() . '/js/jquery.waypoints.js', array( 'jquery' ), '1.0.0', true);
	/* Sticky Menu */
	wp_enqueue_script('jquery.appear.min.js', get_template_directory_uri() . '/js/jquery.appear.min.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('jquery.shuffle..min.js', get_template_directory_uri() . '/js/jquery.shuffle.min.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('hover.min.js', get_template_directory_uri() . '/js/hover.min.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('jquery.magnific-popup.min.js', get_template_directory_uri() . '/js/magnific-popup/jquery.magnific-popup.min.js', array( 'jquery' ), '1.0.0', true);
	//----------------------------Rev Slider----------------------------
	if ( !depilex_is_plugin_active('revslider/revslider.php') ) {
	wp_enqueue_script('jquery.themepunch.tools.min.js', get_template_directory_uri() . '/js/revolution/js/jquery.themepunch.tools.min.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('jquery.themepunch.revolution.min.js', get_template_directory_uri() . '/js/revolution/js/jquery.themepunch.revolution.min.js', array( 'jquery' ), '1.0.0', true);
	wp_enqueue_script('jquery.themepunch.tools.min.js', get_template_directory_uri() . '/js/revolution/js/jquery.themepunch.tools.min.js', array( 'jquery' ), '1.0.0', true);
	}
	//----------------------------Rev Slider End----------------------------
	/* Custom */
	wp_enqueue_script('depilex-custom', get_template_directory_uri() . '/js/depilex-custom.js', array( 'jquery' ), '1.0.0', true);
	/* Scroll Up */
	if(depilex_get_option('depilex_smooth_scroll') == '1') {
	wp_enqueue_script('depilex-totop', get_template_directory_uri() . '/js/scrolltotop/smooth-totop.js', array( 'jquery' ), '1.0.0', true);
	} else {
	wp_enqueue_script('depilex-totop', get_template_directory_uri() . '/js/scrolltotop/totop.js', array( 'jquery' ), '1.0.0', true);
	}
	/* Smooth scroll code start from here */
	if(depilex_get_option('depilex_smooth_scroll') == '1') {
	wp_enqueue_script('depilex-TweenMax.min.js', get_template_directory_uri() . '/js/custom_scroll/TweenMax.min.js', array( 'jquery' ), '1.0.0', true);		
	wp_enqueue_script('depilex-ScrollToPlugin.js', get_template_directory_uri() . '/js/custom_scroll/ScrollToPlugin.js', array( 'jquery' ), '1.0.0', true);			
	wp_enqueue_script('depilex-custom_smooth_scroll.js', get_template_directory_uri() . '/js/custom_scroll/custom_smooth_scroll.js', array( 'jquery' ), '1.0.0', true);
	}

	wp_localize_script( 'depilex-main', 'prefix_object_name', array(
		'error_while_ajax_request' => esc_html__( 'Error while ajax request', 'depilex' ),
		'thank_you_your_email_has_been_sent' => esc_html__( 'Thank you, your email has been sent', 'depilex' ),
		'please_try_again' => esc_html__( 'Please, fill in all the required fields correctly!', 'depilex' )
	) );
}
add_action( 'wp_enqueue_scripts', 'depilex_scripts_basic' ); 

function depilex_styles_basic()  {  
	$depilex_page_id_for_posts = get_option( 'page_for_posts' );
	global $wp_query;
	$postid = $wp_query->post->ID;
	if ( is_home() ) {
	$header_styles = get_post_meta($depilex_page_id_for_posts, 'header_key', true);
	} else {
	$header_styles = get_post_meta($postid, 'header_key', true);
	}
	/* ------------------------------------------------------------------------ */
	/* Enqueue Stylesheets */
	/* ------------------------------------------------------------------------ */
	/* Fonts */
	wp_enqueue_style( 'depilex-fonts-dosis', depilex_fonts_dosis_url(), array(), null );
	wp_enqueue_style( 'depilex-fonts-opensans', depilex_fonts_opensans_url(), array(), null );
	/* Bootstrap */
	wp_enqueue_style( 'bootstrap.css', get_template_directory_uri() . '/css/bootstrap.css');
	/* CSS STYLES */
	if(depilex_get_option('depilex_preloader') == '1') {
	wp_enqueue_style( 'depilex-preloader', get_template_directory_uri() . '/css/preloader.css');
	}
	wp_enqueue_style( 'depilex-stylesheet', get_template_directory_uri() . '/style.css'); // Main Stylesheet
	wp_enqueue_style( 'depilex-spa', get_template_directory_uri() . '/css/spa-style.css'); // For Spa demo 
	if( ( $header_styles == 'style_four' ) || ( $header_styles == 'style_three' ) ){
	wp_enqueue_style( 'depilex-header-two', get_template_directory_uri() . '/css/header-two.css'); //For Heaer Style 3 and 4
	}
	wp_enqueue_style( 'depilex-reset', get_template_directory_uri() . '/css/reset.css');
	wp_enqueue_style( 'font-awesome.css', get_template_directory_uri() . '/css/font-awesome.css');
	wp_enqueue_style( 'et-line-fonts.css', get_template_directory_uri() . '/css/et-line-fonts.css');
	wp_enqueue_style( 'flaticon.css', get_template_directory_uri() . '/css/flaticon.css');
	wp_enqueue_style( 'flaticon-spa.css', get_template_directory_uri() . '/css/flaticon-spa.css'); // For Spa demo
	/* Mega Menu */
	wp_enqueue_style( 'depilex-magnific-popup', get_template_directory_uri() . '/js/magnific-popup/magnific-popup.css');
	//----------------------------Rev Slider----------------------------
	if ( !depilex_is_plugin_active('revslider/revslider.php') ) {
	wp_enqueue_style( 'depilex-rev-settings.css', get_template_directory_uri() . '/js/revolution/css/settings.css');
	}
	//----------------------------Rev Slider End----------------------------
}  
add_action( 'wp_enqueue_scripts', 'depilex_styles_basic', 1 );

function depilex_enqueue_comment_reply() {
    if ( get_option( 'thread_comments' ) ) { 
        wp_enqueue_script( 'comment-reply' ); 
    }
	}
	// Hook into comment_form_before
	add_action( 'comment_form_before', 'depilex_enqueue_comment_reply' );
?>
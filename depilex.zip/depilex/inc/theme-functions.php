<?php
// **********************************************************************// 
// ! Supports post thumbnails and post formats
// **********************************************************************// 
add_theme_support( 'post-thumbnails' );
add_theme_support( 'post-formats', array( 'video' ) );
add_theme_support( 'custom-logo', array(
   'height'      => 35,
   'width'       => 200,
   'flex-width' => true,
) );
function depilex_the_custom_logo() {
   if ( function_exists( 'the_custom_logo' ) ) {
      the_custom_logo();
   }
}
	
// **********************************************************************// 
// ! Rss feeds, Custom Background and Title Tag theme supports
// **********************************************************************// 
add_theme_support( 'automatic-feed-links' );
add_theme_support('custom-background', array(
        'default-color' => '#ffffff',
    ));
add_theme_support( 'custom-header', array(
		'default-text-color'     => '#000'
	) );
add_theme_support( 'title-tag' );
function depilex_add_editor_styles() {
    add_editor_style( 'css/bootstrap.css' );
}
add_action( 'admin_init', 'depilex_add_editor_styles' );

// **********************************************************************// 
// ! This theme uses wp_nav_menu() for Main Menu
// **********************************************************************// 
register_nav_menus( array(
		'depilex_primary_menu'=> __('Main Menu', 'depilex'),
		'depilex_menu_footer'=> __('Footer Menu', 'depilex')
) );

// **********************************************************************// 
// ! Getting Theme Fonts
// **********************************************************************//
// ! Opensans Font
function depilex_fonts_opensans_url() {
$fonts_url = '';
 
/* Translators: If there are characters in your language that are not
* supported by Open Sans, translate this to 'off'. Do not translate
* into your own language.
*/
$open_sans = _x( 'on', 'Open Sans font: on or off', 'depilex' );

$font_families = array();
 
if ( 'off' !== $open_sans ) {
$font_families[] = 'Open Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic';
}
 
$query_args = array(
'family' => urlencode( implode( '|', $font_families ) ),
'subset' => urlencode( 'latin,latin-ext' ),
);
 
$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
 
return esc_url_raw( $fonts_url );
}

// ! Dosis Font
function depilex_fonts_dosis_url() {
$fonts_url = '';
 
/* Translators: If there are characters in your language that are not
* supported by Dosis, translate this to 'off'. Do not translate
* into your own language.
*/
$open_sans = _x( 'on', 'Dosis font: on or off', 'depilex' );

$font_families = array();
 
if ( 'off' !== $open_sans ) {
$font_families[] = 'Dosis:300,700,600';
}
 
$query_args = array(
'family' => urlencode( implode( '|', $font_families ) ),
'subset' => urlencode( 'latin,latin-ext' ),
);
 
$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
 
return esc_url_raw( $fonts_url );
}

// **********************************************************************// 
// ! Custom Walker for wp_nav_menu()
// **********************************************************************//
class depilex_walker_nav_menu extends Walker_Nav_Menu {

private $blog_sidebar_pos = "";
// add classes to ul sub-menus
function start_lvl( &$output, $depth = 0, $args = Array() ) {
    // depth dependent classes
    $indent = ( $depth > 0  ? str_repeat( "\t", $depth ) : '' ); // code indent
    $display_depth = ( $depth + 1); // because it counts the first submenu as 0
    $classes = array(
        'dropdown-menu',
        ( $display_depth % 2  ? 'menu-odd' : 'menu-even' ),
        ( $display_depth >=2 ? '' : '' ),
        'menu-depth-' . $display_depth
        );
    $class_names = implode( ' ', $classes );
  
    // build html
	
	$output .= "\n" . $indent . '<ul class="' . $class_names . '">' . "\n";
}
  
// add main/sub classes to li's and links
 function start_el( &$output, $item, $depth = 0, $args = Array(), $id = 0 ) {
    global $wp_query;
    $indent = ( $depth > 0 ? str_repeat( "\t", $depth ) : '' ); // code indent
  
    // depth dependent classes
	$depth_classes = array(
        ( $depth == 0 ? '' : '' ), //class for the top level menu which got sub-menu
		( $depth >=1 ? '' : '' ), //class for the level-1 sub-menu which got level-2 sub-menu
        ( $depth >=2 ? 'sub-sub-menu-item' : '' ), //class for the level-2 sub-menu which got level-3 sub-menu
        ( $depth % 2 ? 'menu-item-odd' : 'menu-item-even' ),
        'menu-item-depth-' . $depth
    );
    $depth_class_names = esc_attr( implode( ' ', $depth_classes ) );
  
    // passed classes
    $classes = empty( $item->classes ) ? array() : (array) $item->classes;
    $class_names = esc_attr( implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) ) );
  
    // build html
    $output .= $indent . '<li id="nav-menu-item-'. $item->ID . '" class="' . $depth_class_names . ' ' . $class_names . '">';
  
    // link attributes
    $attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
    $attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
    $attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';
    $attributes .= ! empty( $item->url )        ? ' href="'   . esc_attr( $item->url        ) .'"' : '';
    $attributes .= ' class="' . ( $depth > 0 ? '' : '' ) . '"';

	$item_output = sprintf( '%1$s<a%2$s>%3$s%4$s%5$s</a>%6$s',
        $args->before,
        $attributes,
        $args->link_before,
        apply_filters( 'the_title', $item->title, $item->ID ),
        $args->link_after,
        $args->after
    );
  
    // build html
    $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args, $id );
}
} //End Walker_Nav_Menu

// **********************************************************************// 
// ! Add breadcrumbs
// **********************************************************************//
function depilex_wordpress_breadcrumbs() {
 
  $allowed_html_array = array(
    'a' => array(),
    'span' => array(),
	);
  $delimiter = wp_kses( __( '<span>/</span>', 'depilex' ), $allowed_html_array );  
  $name = 'Home'; //text for the 'Home' link
  $currentBefore = '';
  $currentAfter = '';
 
  if ( !is_home() && !is_front_page() || is_paged() ) {
 
    echo '';
 
    global $post;
    $home = home_url();
	echo '<a href="' . esc_url($home) . '">' . $name . '</a> ' . $delimiter . ' ';
 
    if ( is_category() ) {
      global $wp_query;
      $cat_obj = $wp_query->get_queried_object();
      $thisCat = $cat_obj->term_id;
      $thisCat = get_category($thisCat);
      $parentCat = get_category($thisCat->parent);
      if ($thisCat->parent != 0) echo(get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' '));
	  echo wp_kses( __( '' . $currentBefore . ' Archive by category &#39;', 'depilex' ), $allowed_html_array );
      single_cat_title();
	  echo wp_kses( __( '&#39;' . $currentBefore . '', 'depilex' ), $allowed_html_array );
 
    } elseif ( is_day() ) {
	  echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . '';
	  echo '<a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' ';
	  echo esc_attr($currentBefore) . get_the_time('d') . esc_attr($currentAfter);
 
    } elseif ( is_month() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
      echo esc_attr($currentBefore) . get_the_time('F') . esc_attr($currentAfter);
 
    } elseif ( is_year() ) {
      echo esc_attr($currentBefore) . get_the_time('Y') . esc_attr($currentAfter);
 
    } elseif ( is_single() ) {
      $cat = get_the_category(); $cat = (isset($cat[0]) ? $cat[0] : null);
      echo is_wp_error( $cat_parents = get_category_parents($cat, TRUE, '' . $delimiter . '') ) ? '' : $cat_parents;
      echo esc_attr($currentBefore);
      the_title();
      echo esc_attr($currentAfter);
 
    } elseif ( is_page() && !$post->post_parent ) {
      echo esc_attr($currentBefore);
      the_title();
      echo esc_attr($currentAfter);
 
    } elseif ( is_page() && $post->post_parent ) {
      $parent_id  = $post->post_parent;
      $breadcrumbs = array();
      while ($parent_id) {
        $page = get_page($parent_id);
        $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
        $parent_id  = $page->post_parent;
      }
      $breadcrumbs = array_reverse($breadcrumbs);
      //foreach ($breadcrumbs as $crumb) echo esc_url($crumb) . ' ' . $delimiter . ' '; //remove esc_url from $crumb
	  foreach ($breadcrumbs as $crumb) echo wp_kses( __( $crumb, 'depilex' ), $allowed_html_array ) . ' ' . $delimiter . ' ';
      echo esc_attr($currentBefore);
      the_title();
      echo esc_attr($currentAfter);
 
    } elseif ( is_search() ) {
      echo esc_attr($currentBefore) . 'Search results for &#39;' . get_search_query() . '&#39;' . esc_attr($currentAfter);
 
    } elseif ( is_tag() ) {
      echo $currentBefore . 'Posts tagged &#39;';
      single_tag_title();
      echo '&#39;' . esc_attr($currentAfter);
 
    } elseif ( is_author() ) {
       global $author;
      $userdata = get_userdata($author);
      echo esc_attr($currentBefore) . 'Articles posted by ' . $userdata->display_name . esc_attr($currentAfter);
 
    } elseif ( is_404() ) {
      echo esc_attr($currentBefore) . 'Error 404' . esc_attr($currentAfter);
    }
 
    if ( get_query_var('paged') ) {
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
      echo __('Page', 'depilex') . ' ' . get_query_var('paged');
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
    }
 
    echo '';
 
  }
}
/// Breadcrumbs End ///

// **********************************************************************// 
// ! Function to Check if a Plugin is Active
// **********************************************************************// 
function depilex_is_plugin_active( $plugin ) {
    return in_array( $plugin, (array) get_option( 'active_plugins', array() ) );
}
// **********************************************************************// 
// ! Register Sidebars
// **********************************************************************//
if ( ! function_exists( 'depilex_widgets_init' ) ) {
	function depilex_widgets_init() {

		register_sidebar( array(
		'name' => esc_html__( 'Sidebar', 'depilex' ),
		'id' => 'depilex_sidebar',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2>',
		'after_title' => '</h2>',
	) );
	}
}
add_action( 'widgets_init', 'depilex_widgets_init' );

// **********************************************************************// 
// ! Remove the parentheses and surround the post count with a span
// **********************************************************************//
function categories_postcount_filter ($variable) {
   $variable = str_replace('(', '<span class="deplix_post_count">( ', $variable);
   $variable = str_replace(')', ' )</span>', $variable);
   return $variable;
}
add_filter('wp_list_categories','categories_postcount_filter');

function archive_postcount_filter ($variable) {
   $variable = str_replace('(', '<span class="deplix_post_count">( ', $variable);
   $variable = str_replace(')', ' )</span>', $variable);
   return $variable;
}
add_filter('get_archives_link', 'archive_postcount_filter');

// **********************************************************************// 
// ! Get Global Variables
// **********************************************************************//
function depilex_get_global_post() {
    global $post;
    if ( 
        ! $post instanceof \WP_Post
    ) {
        return false;
    }
    return $post;
}

function depilex_get_global_wpquery() {
    global $wp_query;
    return $wp_query;
}

// **********************************************************************// 
// ! Custom Pagination
// **********************************************************************//
function depilex_custom_pagination() {
	global $wp_query;

	$big = 999999999; // need an unlikely integer
		
	echo paginate_links( array(
		'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
		'format' => '?paged=%#%',
		'current' => max( 1, get_query_var('paged') ),
		'total' => $wp_query->max_num_pages,
		'show_all'     => false,
		'end_size'     => 1,
		'mid_size'     => 2,
		'prev_next'    => true,
		'prev_text'    => '<span class="fa fa-angle-double-left"></span>',
		'next_text'    => '<span class="fa fa-angle-double-right"></span>',
		'type'         => 'list',
		'add_args'     => false,
		'add_fragment' => ''
	) );
}

// **********************************************************************// 
// ! Excerpt Limit
// **********************************************************************//
function depilex_excerpt($limit) {
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt).'...';
  } else {
    $excerpt = implode(" ",$excerpt);
  }	
  $excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
  return $excerpt;
}

if ( ! function_exists( 'depilex_excerpt_length' ) ) {
	function depilex_excerpt_length( $length ) {
	return 65;
	}
}
add_filter( 'excerpt_length', 'depilex_excerpt_length', 999 );

// **********************************************************************// 
// ! Set Content Width
// **********************************************************************// 
if (!isset($content_width)) { $content_width = 750; }

add_filter('get_avatar','add_gravatar_class');

// **********************************************************************// 
// ! Adding Class to Gravatar image
// **********************************************************************//
function add_gravatar_class($class) {
    $class = str_replace("class='avatar", "class='avatar img-circle", $class);
    return $class;
}
// **********************************************************************// 
// ! Display Comments section
// **********************************************************************//
if ( ! function_exists( 'depilex_comment' ) ) {
/**
 * Template for comments and pingbacks.
 *
 * To override this walker in a child theme without modifying the comments template
 * simply create your own depilex_comment(), and that function will be used instead.
 *
 * Used as a callback by wp_list_comments() for displaying the comments.
 */
	function depilex_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;

	global $post;
	?>
	<div <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
	<div class="media">
			<a class="media-left" href="javascript:void(0)"><?php echo get_avatar($comment, 80); ?></a>
		<div class="media-body">
            <span class="media-heading"><a href="javascript:void(0)"><?php comment_author(); ?></a></span>
			<div class="comment-meta">
			  <p><a href="javascript:void(0)"><?php comment_date('d M, Y') ?></a> / <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))); ?></p>
			</div>
              <?php comment_text()?>
		</div>
	</div>
	<!-- #comment-## -->

	<?php
	}
}

/*******************
Comment form styling
*******************/
if ( ! function_exists( 'depilex_modify_comment_fields' ) ) {
	function depilex_modify_comment_fields($fields) {

    $fields['fields'] = '<div class="row"><div class="col-sm-6"><div class="form-group"><label>'.esc_html__("Name", 'depilex').'<span class="required">*</span></label>
                      <input type="text" id="author" name="author" class="form-control" placeholder="'.esc_html__("Name", 'depilex').'"';
	$n_value = '';
	$e_value = '';

	$fields['fields'] .= ' value="'.esc_attr($n_value).'" aria-required="true" /></div></div>
						  <div class="col-sm-6"><div class="form-group">';
    $fields['fields'] .= '<label>'.esc_html__("Email", 'depilex').'<span class="required">*</span></label>
							<input type="email" id="email" name="email" class="form-control" placeholder="'.esc_html__("Email", 'depilex').'" value="'.esc_attr($e_value).'" aria-required="true" /></div></div>';
	return $fields;
	}
}

add_filter('comment_form_defaults', 'depilex_modify_comment_fields');//Name, Email and Website fields customization filter

if ( !is_user_logged_in() ) { 
if ( ! function_exists( 'depilex_comment_field' ) ) {
	function depilex_comment_field($arg) {
  
	$arg['comment_field'] = '
								<div class="col-sm-12"><div class="form-group"><label>'.esc_html__("Comment", 'depilex').'<span class="required">*</span></label>
								<textarea name="comment" id="comment" rows="10" class="form-control"></textarea></div></div>
							 ';    
	return $arg;
	}
}
add_filter('comment_form_defaults', 'depilex_comment_field');//Text area customization filter
} else {
if ( ! function_exists( 'depilex_comment_field' ) ) {
	function depilex_comment_field($arg) {
  
	$arg['comment_field'] = '
								<div class="col-sm-12 row"><div class="form-group"><label>'.esc_html__("Comment", 'depilex').'<span class="required">*</span></label>
								<textarea name="comment" id="comment" rows="10" class="form-control"></textarea></div></div>
							 ';    
	return $arg;
	}
}
add_filter('comment_form_defaults', 'depilex_comment_field');//Text area customization filter
}

if ( !is_user_logged_in() ) {
function depilex_comment_form_submit_button($button) {
	$button =
		'
            <div class="col-sm-6">
                 <button name="submit" type="submit" id="[args:id_submit]" value="[args:label_submit]" class="btn btn-primary">'.esc_html__("Post  your comment", 'depilex').'</button>
            </div> <!-- End col-sm-6 -->
			</div><!--End row-->
         ';// .
		//get_comment_id_fields();
	return $button;
}
add_filter('comment_form_submit_button', 'depilex_comment_form_submit_button');//Submit button customization filter
} else {
function depilex_comment_form_submit_button($button) {
	$button =
		'
            <div class="col-sm-6 row">
                 <button name="submit" type="submit" id="[args:id_submit]" value="[args:label_submit]" class="btn btn-primary">'.esc_html__("Post  your comment", 'depilex').'</button>
            </div> <!-- End col-sm-6 -->
         ';// .
		//get_comment_id_fields();
	return $button;
}
add_filter('comment_form_submit_button', 'depilex_comment_form_submit_button');//Submit button customization filter
}

function depilex_move_comment_field_to_bottom( $fields ) {
$comment_field = $fields['comment'];
unset( $fields['comment'] );
$fields['comment'] = $comment_field;

return $fields;
}
add_filter( 'comment_form_fields', 'depilex_move_comment_field_to_bottom' );//move the comment text field to the bottom
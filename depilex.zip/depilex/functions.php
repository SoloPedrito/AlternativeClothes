<?php
function depilex_get_global_themedata() {
    global $depilex_theme_data;
    return $depilex_theme_data;
}
$depilex_themes_data = depilex_get_global_themedata();
$depilex_themes_data = wp_get_theme( get_stylesheet_directory() . '/style.css' );

/* -----------------------------------------------------------------------------
 * Definations
 * -------------------------------------------------------------------------- */
if( !defined('DEPILEX_ADMIN_PATH') )
	define( 'DEPILEX_ADMIN_PATH', get_template_directory() . '/framework/admin/' );
if( !defined('DEPILEX_INIT_PATH') )
	define( 'DEPILEX_INIT_PATH', get_template_directory() . '/framework/' );
if( !defined('DEPILEX_INCLUDE_PATH') )
	define( 'DEPILEX_INCLUDE_PATH', get_template_directory() . '/inc/' );
if( !defined('DEPILEX_LANGUAGE_PATH') )
	define( 'DEPILEX_LANGUAGE_PATH', get_template_directory() . '/languages/' );

require_once( DEPILEX_INIT_PATH . 'init.php' );
		<form method="get" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>" id="searchform">
                        	<div class="form-group">
                          <input id="s" type="text" placeholder="<?php esc_html_e('Search..', 'depilex'); ?>" class="form-control" name="s">
                          <button class="sea-icon" type="submit"><i class="icon-magnifying-glass"></i></button>
                        </div>
						</form>
<?php
/**
 * 404 page
 */
get_template_part( 'error', 'header' ); ?>
<!-- =-=-=-=-=-=-= PAGE SECTION =-=-=-=-=-=-= -->
<div id="page-section"> 
  <!-- =-=-=-=-=-=-= Error Page =-=-=-=-=-=-= -->
        <section class="error-page full-page">
            <div class="container">
                <div class="error-container">
                    <h1><?php esc_html_e('404', 'depilex'); ?></h1>
                    <span class="error-title"><?php esc_html_e('OOPS! PAGE NOT FOUND FOUND', 'depilex'); ?></span>
                    <p><?php esc_html_e('Sorry, but we cannot seem to find the page you are looking for.', 'depilex'); ?></p>
                   
                    <br>

                    <a class="btn btn-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e('Take Me Home', 'depilex'); ?></a>
                </div>
            </div>
        </section>
  <!-- =-=-=-=-=-=-= Error Page  END =-=-=-=-=-=-= --> 
</div>
<!-- =-=-=-=-=-=-= PAGE SECTION END =-=-=-=-=-=-= -->
  
  <?php get_template_part( 'error', 'footer' ); ?>
<?php
/**
 * The default page template of this theme
 */
get_header(); ?>
<!-- =-=-=-=-=-=-= PAGE HEADING SECTION =-=-=-=-=-=-= -->
  <section class="page-heading breadcrumb-image" <?php if(depilex_get_option('depilex_page_header_img') != '') { ?>style="background: rgba(0, 0, 0, 0) url('<?php echo esc_url( depilex_get_option('depilex_page_header_img') ); ?>'); background-repeat: no-repeat; background-size: cover; background-position: center center; background-attachment: fixed;"<?php } ?>>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="page-heading_content text-center">
            <h1><span><?php if (have_posts()) :  while (have_posts()) : the_post(); the_title(); endwhile; endif; ?></span></h1>
            <div class="bredcrumbs"><?php if (function_exists('depilex_wordpress_breadcrumbs')) depilex_wordpress_breadcrumbs(); ?></div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- =-=-=-=-=-=-= PAGE HEADING SECTION END =-=-=-=-=-=-= -->
  
  <section class="section-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12"> 
			
				<?php if (have_posts()) :  while (have_posts()) : the_post(); 
					$depilex_global_post = depilex_get_global_post();
					$postid = $depilex_global_post->ID;
					$get_image = esc_url( wp_get_attachment_url( get_post_thumbnail_id($postid) ) ); 
				?>
		<!-- post grid -->
        <!-- image grid -->
		<?php if ( has_post_thumbnail()) : ?>
        <div class="post-image zoom-pic">
            <a href="<?php the_permalink(); ?>"><img alt="" class="img-responsive" src="<?php echo esc_url( $get_image ); ?>"></a>
        </div>
		<?php endif; ?>
		<!-- image grid end -->
        <!-- post content -->
        <div class="post-content">

					<?php the_content(); ?>

        </div>
          <!-- post grid end -->
		  <div class="clearfix"></div>
		  
		<span class="separator"></span>    
		<div class="custom-pagination text-center">
            <?php wp_link_pages( array(
						'before'      => '<ul>',
						'after'       => '</ul>',
						'link_before' => '',
						'link_after'  => '',
						'next_or_number' => 'next',
						) );
					?>
        </div>
		<?php endwhile; endif; ?>
		<div class="clearfix"></div>
        <div id="comments" class="col-md-12">
		<?php comments_template( '', true ); ?>
		</div>
						
      </div>

    </div>
    </div>
  </section>
  <!-- end -->
  <?php get_footer(); ?>
<?php
/**
 * Template name: Project Details Page
 */
get_header(); ?>
<!-- =-=-=-=-=-=-= PAGE HEADING SECTION =-=-=-=-=-=-= -->
  <section class="page-heading breadcrumb-image" <?php if(depilex_get_option('depilex_page_header_img') != '') { ?>style="background: rgba(0, 0, 0, 0) url('<?php echo esc_url( depilex_get_option('depilex_page_header_img') ); ?>'); background-repeat: no-repeat; background-size: cover; background-position: center center; background-attachment: fixed;"<?php } ?>>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="page-heading_content text-center">
            <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
            <h1><span><?php the_title(); ?></span>
			</h1>
			<?php endwhile; endif; ?>
            <div class="bredcrumbs"><?php if (function_exists('depilex_wordpress_breadcrumbs')) depilex_wordpress_breadcrumbs(); ?></div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- =-=-=-=-=-=-= PAGE HEADING SECTION END =-=-=-=-=-=-= -->

<section class="padding-top-120">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
			
				<?php if (have_posts()) :  while (have_posts()) : the_post(); 
					$depilex_global_post = depilex_get_global_post();
					$postid = $depilex_global_post->ID;
					$get_image = esc_url( wp_get_attachment_url( get_post_thumbnail_id($postid) ) ); 
				?>
		<!-- post grid -->
		
        <div <?php post_class( 'post-block' ); ?> id="post-<?php the_ID(); ?>">
		<!-- image grid -->
		<?php if ( has_post_thumbnail()) : ?>
        <div class="post-image zoom-pic">
            <a href="<?php the_permalink(); ?>"><img alt="" class="img-responsive" src="<?php echo esc_url( $get_image ); ?>"></a>
        </div>
		<?php endif; ?>
		<!-- image grid end -->
		<span class="meta-bg"><span class="date"><?php echo get_the_time('j'); ?></span><span><?php echo get_the_time('M'); ?></span></span>
            <h2><a class="post-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
        <!-- post content -->
        <div class="post-content">

					<?php the_content(); ?>

        </div>
          <!-- post grid end -->
		<div class="padding-top-30"><hr></div>
		</div>
		<?php endwhile; endif; ?>
						
	  </div>

    </div>
    </div>
  </section>
  <!-- end -->
  <?php get_footer(); ?>
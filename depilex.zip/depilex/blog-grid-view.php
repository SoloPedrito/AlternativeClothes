<?php
/**
 * Template name: Blog Grid View
 */
get_header(); ?>
  <!-- =-=-=-=-=-=-= PAGE HEADING SECTION =-=-=-=-=-=-= -->
  <section class="page-heading breadcrumb-image" <?php if(depilex_get_option('depilex_page_header_img') != '') { ?>style="background: rgba(0, 0, 0, 0) url('<?php echo esc_url( depilex_get_option('depilex_page_header_img') ); ?>'); background-repeat: no-repeat; background-size: cover; background-position: center center; background-attachment: fixed;"<?php } ?>>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="page-heading_content text-center">
            <?php if (depilex_get_option('depilex_page_header_title') != '') : ?>
            <h1><span><?php echo esc_html( depilex_get_option('depilex_page_header_title') ); ?></span>
			</h1>
			<?php else : ?>			
			<h1><span><?php if ( (is_front_page()) || (is_home()) ) : ?>
							<?php bloginfo('name'); ?>
						<?php else : ?>
							<?php printf( esc_html__( 'Blog Archives', 'depilex' )); ?>
						<?php endif; ?></span>
			</h1>
			<?php endif; ?>
            <div class="bredcrumbs"><?php if (function_exists('depilex_wordpress_breadcrumbs')) depilex_wordpress_breadcrumbs(); ?></div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- =-=-=-=-=-=-= PAGE HEADING SECTION END =-=-=-=-=-=-= -->

<section class="section-padding">
    <div class="container">
      <div class="row">
	   <div class="blog-grid padding-top-30">
			
				<?php 	
						if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
						elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
						else { $paged = 1; }
						$args = array('order'=> 'DESC', 'paged' => $paged, 'orderby' => 'post_date' );
						query_posts($args);
						$title = get_the_title();						
				?>

			<div class="row">
			<div class="col-sm-6">
				<?php $i = 0; if (have_posts()) : while(have_posts()) : $i++; if(($i % 2) == 0) : $wp_query->next_post(); else : the_post();
					$depilex_global_post = depilex_get_global_post();
					$postid = $depilex_global_post->ID;
					$get_image = esc_url( wp_get_attachment_url( get_post_thumbnail_id($postid) ) );
					$category = get_the_category($postid);
				?>
			
		  <div <?php post_class( 'col-sm-12 col-xs-12 col-md-12 col-lg-12 blog-post' ); ?> id="post-<?php the_ID(); ?>">
          
            <div class="blog-container"> 
				<?php if ( has_post_thumbnail()) : ?>
					<a href="<?php the_permalink(); ?>"><img alt="" class="img-responsive" src="<?php echo esc_url( $get_image ); ?>"></a>
				<?php endif; ?>
              <div class="blog-overlay-down <?php if ( !has_post_thumbnail()) : ?>blog-overlay-down-relative<?php endif; ?>">
                <div class="blog-title">
                  <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
				  <?php if(depilex_get_option('depilex_blog_post_meta') == '1') { ?>
                  <div class="blog-content-meta hidden-sm">  <?php if ( has_category() ) { ?><i class="fa fa-sitemap"></i> <a href="<?php echo get_category_link( $category[0]->term_id ) ?>"><?php echo $category[0]->cat_name ?></a> &nbsp; <?php } ?><i class="fa fa-comment-o"></i> <a href="<?php echo get_comments_link(); ?>"> <?php echo get_comments_number(); ?> <?php esc_html_e('Comments', 'depilex'); ?></a> &nbsp; <i class="fa fa-calendar"></i> <a href="#"> <?php echo get_the_time('M j, Y'); ?></a> &nbsp; </div>
				  <?php } ?>
                </div>
              </div>
            </div>
            <div class="blog-description">
              <?php if ( has_post_format( 'video' ) ) : ?>
					<?php the_content(); ?>
					<?php else: ?>
					<?php the_excerpt(); ?>
			<?php endif; ?>
              <div class="read-more"> <a class="btn btn-blog btn-default" href="<?php the_permalink(); ?>"><i class="fa fa-plus"></i> <?php if(depilex_get_option('depilex_readmore_label') != '') { ?><?php echo esc_html( depilex_get_option('depilex_readmore_label') ); ?><?php } else { ?><?php esc_html_e('Read More', 'depilex'); ?><?php } ?></a> </div>
            </div>
          </div>	
		  <?php endif; endwhile; endif; ?>
			</div>

			<div class="col-sm-6">
			<?php $i = 0; rewind_posts(); ?>
			<?php if (have_posts()) : while(have_posts()) : $i++; if(($i % 2) !== 0) : $wp_query->next_post(); else : the_post(); 
					$depilex_global_post = depilex_get_global_post();
					$postid = $depilex_global_post->ID;
					$get_image = esc_url( wp_get_attachment_url( get_post_thumbnail_id($postid) ) );
					$category = get_the_category($postid);
			?>
				
			<div <?php post_class( 'col-sm-12 col-xs-12 col-md-12 col-lg-12 blog-post' ); ?> id="post-<?php the_ID(); ?>">
          
            <div class="blog-container"> 
				<?php if ( has_post_thumbnail()) : ?>
					<a href="<?php the_permalink(); ?>"><img alt="" class="img-responsive" src="<?php echo esc_url( $get_image ); ?>"></a>
				<?php endif; ?>
              <div class="blog-overlay-down <?php if ( !has_post_thumbnail()) : ?>blog-overlay-down-relative<?php endif; ?>">
                <div class="blog-title">
                  <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
				  <?php if(depilex_get_option('depilex_blog_post_meta') == '1') { ?>
                  <div class="blog-content-meta hidden-sm">  <?php if ( has_category() ) { ?><i class="fa fa-sitemap"></i> <a href="<?php echo get_category_link( $category[0]->term_id ) ?>"><?php echo $category[0]->cat_name ?></a> &nbsp; <?php } ?><i class="fa fa-comment-o"></i> <a href="<?php echo get_comments_link(); ?>"> <?php echo get_comments_number(); ?> <?php esc_html_e('Comments', 'depilex'); ?></a> &nbsp; <i class="fa fa-calendar"></i> <a href="#"> <?php echo get_the_time('M j, Y'); ?></a> &nbsp; </div>
				  <?php } ?>
                </div>
              </div>
            </div>
            <div class="blog-description">
              <?php if ( has_post_format( 'video' ) ) : ?>
					<?php the_content(); ?>
					<?php else: ?>
					<?php the_excerpt(); ?>
			<?php endif; ?>
              <div class="read-more"> <a class="btn btn-blog btn-default" href="<?php the_permalink(); ?>"><i class="fa fa-plus"></i> <?php if(depilex_get_option('depilex_readmore_label') != '') { ?><?php echo esc_html( depilex_get_option('depilex_readmore_label') ); ?><?php } else { ?><?php esc_html_e('Read More', 'depilex'); ?><?php } ?></a> </div>
            </div>
          </div>
		  
			<?php endif; endwhile; endif; ?>
		  </div>
		  </div>
		  
        <div class="clearfix"></div>
          
          <span class="separator"></span>         
              <div class="custom-pagination text-center">
                <?php depilex_custom_pagination(); ?>
              </div>
						
	 </div>
    </div>
    </div>
  </section>
  <!-- end -->
  <?php get_footer(); ?>